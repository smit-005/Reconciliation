import 'dart:math' as math;
import 'dart:async';
import 'dart:io' show Platform;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:reconciliation_app/core/utils/normalize_utils.dart';
import 'package:reconciliation_app/core/widgets/app_compact_select_field.dart';
import 'package:reconciliation_app/core/widgets/app_search_autocomplete_field.dart';
import 'package:reconciliation_app/features/reconciliation/presentation/widgets/seller_mapping_summary_cards.dart';
import 'package:reconciliation_app/features/reconciliation/presentation/widgets/seller_mapping_theme.dart';
import 'package:reconciliation_app/core/widgets/app_status_badge.dart';
import 'package:reconciliation_app/features/reconciliation/presentation/widgets/seller_mapping_models.dart';
import 'package:reconciliation_app/features/reconciliation/models/seller_mapping.dart';
import 'package:reconciliation_app/features/reconciliation/presentation/models/reconciliation_view_mode.dart';

class SellerMappingScreenRowData {
  final String purchasePartyDisplayName;
  final String normalizedAlias;
  final String sectionCode;
  final String purchasePan;
  final String purchaseGstNo;
  final SellerMappingResolvedSuggestion? resolvedSuggestion;
  final bool isReadOnly;
  final bool isAboveThreshold;
  final bool hasReconciliationMismatch;
  final bool hasNameOrPanConflict;
  final bool hasApplicableTdsImpact;
  final bool is26QUnmatched;
  final bool hasMissingOrUncertainPan;
  final String preflightReasonCode;
  final String preflightReasonLabel;
  final String preflightReasonDetail;
  final bool requiresDangerousReview;
  final bool isPurchaseOnly;

  const SellerMappingScreenRowData({
    required this.purchasePartyDisplayName,
    required this.normalizedAlias,
    required this.sectionCode,
    required this.purchasePan,
    this.purchaseGstNo = '',
    this.resolvedSuggestion,
    this.isReadOnly = false,
    this.isAboveThreshold = false,
    this.hasReconciliationMismatch = false,
    this.hasNameOrPanConflict = false,
    this.hasApplicableTdsImpact = false,
    this.is26QUnmatched = false,
    this.hasMissingOrUncertainPan = false,
    this.preflightReasonCode = '',
    this.preflightReasonLabel = '',
    this.preflightReasonDetail = '',
    this.requiresDangerousReview = false,
    this.isPurchaseOnly = false,
  });
}

class SellerMappingResolvedSuggestion {
  final String mappedName;
  final String mappedPan;
  final String source;
  final String helperText;

  const SellerMappingResolvedSuggestion({
    required this.mappedName,
    required this.mappedPan,
    required this.source,
    this.helperText = '',
  });
}

class SellerMappingScreenResult {
  final List<Map<String, String>> upserts;
  final List<Map<String, String>> deleted;
  final int dangerousRemaining;

  const SellerMappingScreenResult({
    this.upserts = const <Map<String, String>>[],
    this.deleted = const <Map<String, String>>[],
    this.dangerousRemaining = 0,
  });
}

class SellerMappingScreen extends StatefulWidget {
  final SellerMappingScreenMode mode;
  final String buyerName;
  final String buyerPan;
  final String financialYearLabel;
  final String selectedSectionLabel;
  final ReconciliationViewMode initialViewMode;
  final List<SellerMappingScreenRowData> purchaseRows;
  final List<String> tdsParties;
  final List<SellerMapping> existingMappings;
  final Set<String> blockedAliases;
  final Map<String, List<String>> tdsPartyPans;

  const SellerMappingScreen({
    super.key,
    this.mode = SellerMappingScreenMode.standard,
    required this.buyerName,
    required this.buyerPan,
    required this.financialYearLabel,
    required this.selectedSectionLabel,
    this.initialViewMode = ReconciliationViewMode.summary,
    required this.purchaseRows,
    required this.tdsParties,
    this.existingMappings = const [],
    required this.blockedAliases,
    this.tdsPartyPans = const {},
  });

  @override
  State<SellerMappingScreen> createState() => _SellerMappingScreenState();
}

enum SellerMappingScreenMode { standard, preflight }

class _SellerMappingDisplayRow {
  final SellerMappingRowVm row;
  final String? selectedValue;
  final String selectedPan;
  final String status;
  final AutoMapDecision? autoMapDetail;
  final List<String> helperMessages;
  final int index;
  final bool isLast;
  final bool isExpanded;

  const _SellerMappingDisplayRow({
    required this.row,
    required this.selectedValue,
    required this.selectedPan,
    required this.status,
    required this.autoMapDetail,
    required this.helperMessages,
    required this.index,
    required this.isLast,
    required this.isExpanded,
  });
}

class _SellerMappingScreenState extends State<SellerMappingScreen> {
  static const List<String> _sectionTabOrder = <String>[
    '194Q',
    '194C',
    '194H',
    '194I_A',
    '194I_B',
    '194J_A',
    '194J_B',
  ];
  static const String _allSectionsAuditCode = 'ALL';
  static const int _initialVisibleRowLimit = 100;
  static const int _visibleRowIncrement = 100;

  static const Set<String> _legalSuffixTokens = {
    'M',
    'S',
    'M/S',
    'MS',
    'PVT',
    'PRIVATE',
    'LTD',
    'LIMITED',
    'LLP',
    'CO',
    'COMPANY',
  };

  static const Set<String> _ignoredNameTokens = {'AND', 'THE'};

  Map<String, String> selectedMappings = <String, String>{};
  Map<String, AutoMapDecision> autoMapDetails = <String, AutoMapDecision>{};
  List<String> uniqueTdsParties = <String>[];
  Map<String, List<SellerMappingScreenRowData>> _rowDataBySection =
      <String, List<SellerMappingScreenRowData>>{};
  Map<String, SellerMapping> _exactMappingsByKey = <String, SellerMapping>{};
  Map<String, SellerMapping> _fallbackMappingsByAlias =
      <String, SellerMapping>{};
  String _activeSectionCode = '194Q';
  final Map<String, List<SellerMappingRowVm>> _mappingRowsBySectionCache =
      <String, List<SellerMappingRowVm>>{};
  final Set<String> _clearedRowKeys = <String>{};
  final TextEditingController _searchController = TextEditingController();
  Timer? _searchDebounce;
  String _searchQuery = '';
  String _statusFilter = 'All';
  SellerMappingListView _activeListView = SellerMappingListView.needsAction;
  int _visibleRowLimit = _initialVisibleRowLimit;
  List<SellerMappingRowVm>? _cachedFilteredRows;
  Map<SellerMappingListView, int>? _cachedListViewCounts;
  final Set<String> _expandedRowKeys = <String>{};
  final Stopwatch _screenOpenStopwatch = Stopwatch()..start();
  bool _isInitializing = true;
  bool _firstFrameLogged = false;

  void _invalidateViewCaches({bool resetPage = false}) {
    _cachedFilteredRows = null;
    _cachedListViewCounts = null;
    if (resetPage) {
      _visibleRowLimit = _initialVisibleRowLimit;
    }
  }

  String _rowKey(String alias, String sectionCode) {
    return '${normalizePan(widget.buyerPan)}|'
        '${normalizeName(alias.trim())}|'
        '${normalizeSellerMappingSectionCode(sectionCode)}';
  }

  bool get _isPreflightMode => widget.mode == SellerMappingScreenMode.preflight;

  bool _isRowExpanded(String rowKey) => _expandedRowKeys.contains(rowKey);

  void _toggleRowExpanded(String rowKey) {
    setState(() {
      if (!_expandedRowKeys.add(rowKey)) {
        _expandedRowKeys.remove(rowKey);
      }
    });
  }

  String _separateSelectionValue(SellerMappingRowVm row) {
    return '__SEPARATE__:${row.rowKey}';
  }

  bool _isSeparateSelection(SellerMappingRowVm row, String? value) {
    return value == _separateSelectionValue(row);
  }

  List<String> get _availableSectionCodes {
    final presentSections = _sectionTabOrder
        .where((section) => (_rowDataBySection[section] ?? const []).isNotEmpty)
        .toList();
    if (presentSections.length > 1) {
      return <String>[...presentSections, _allSectionsAuditCode];
    }
    return presentSections;
  }

  List<SellerMappingRowVm> _rowsForActiveSection() {
    return _rowsForSection(_activeSectionCode);
  }

  List<SellerMappingRowVm> _rowsForSection(String sectionCode) {
    return _mappingRowsBySectionCache.putIfAbsent(
      sectionCode,
      () => _buildRowsForSection(sectionCode),
    );
  }

  List<SellerMappingRowVm> _buildRowsForSection(String sectionCode) {
    final sourceRows = sectionCode == _allSectionsAuditCode
        ? _sectionTabOrder
              .expand((section) => _rowDataBySection[section] ?? const [])
              .toList()
        : List<SellerMappingScreenRowData>.from(
            _rowDataBySection[sectionCode] ?? const [],
          );

    final rowMap = <String, SellerMappingRowVm>{};
    for (final row in sourceRows) {
      final aliasKey = normalizeName(row.normalizedAlias.trim());
      final normalizedSection = normalizeSellerMappingSectionCode(
        row.sectionCode,
      );
      if (aliasKey.isEmpty) continue;

      final rowKey = _rowKey(aliasKey, normalizedSection);
      final existing = rowMap[rowKey];
      final displayName = row.purchasePartyDisplayName.trim();
      final purchasePan = normalizePan(row.purchasePan);

      rowMap[rowKey] = SellerMappingRowVm(
        purchasePartyDisplayName: displayName.isNotEmpty
            ? displayName
            : (existing?.purchasePartyDisplayName ?? ''),
        normalizedAlias: aliasKey,
        sectionCode: normalizedSection,
        purchasePan: purchasePan.isNotEmpty
            ? purchasePan
            : (existing?.purchasePan ?? ''),
        purchaseGstNo: row.purchaseGstNo.trim().isNotEmpty
            ? row.purchaseGstNo.trim()
            : (existing?.purchaseGstNo ?? ''),
        exactMapping: _exactMappingsByKey[rowKey] ?? existing?.exactMapping,
        fallbackMapping:
            _fallbackMappingsByAlias[aliasKey] ?? existing?.fallbackMapping,
        resolvedSuggestion:
            row.resolvedSuggestion ?? existing?.resolvedSuggestion,
        isReadOnly: row.isReadOnly || (existing?.isReadOnly ?? false),
        isAboveThreshold:
            row.isAboveThreshold || (existing?.isAboveThreshold ?? false),
        hasReconciliationMismatch:
            row.hasReconciliationMismatch ||
            (existing?.hasReconciliationMismatch ?? false),
        hasNameOrPanConflict:
            row.hasNameOrPanConflict ||
            (existing?.hasNameOrPanConflict ?? false),
        hasApplicableTdsImpact:
            row.hasApplicableTdsImpact ||
            (existing?.hasApplicableTdsImpact ?? false),
        is26QUnmatched:
            row.is26QUnmatched || (existing?.is26QUnmatched ?? false),
        hasMissingOrUncertainPan:
            row.hasMissingOrUncertainPan ||
            (existing?.hasMissingOrUncertainPan ?? false),
        preflightReasonCode: row.preflightReasonCode.trim().isNotEmpty
            ? row.preflightReasonCode.trim()
            : (existing?.preflightReasonCode ?? ''),
        preflightReasonLabel: row.preflightReasonLabel.trim().isNotEmpty
            ? row.preflightReasonLabel.trim()
            : (existing?.preflightReasonLabel ?? ''),
        preflightReasonDetail: row.preflightReasonDetail.trim().isNotEmpty
            ? row.preflightReasonDetail.trim()
            : (existing?.preflightReasonDetail ?? ''),
        requiresDangerousReview:
            row.requiresDangerousReview ||
            (existing?.requiresDangerousReview ?? false),
        isPurchaseOnly:
            row.isPurchaseOnly || (existing?.isPurchaseOnly ?? false),
      );
    }

    final builtRows = rowMap.values.toList()
      ..sort((a, b) {
        final nameCompare = a.purchasePartyDisplayName.compareTo(
          b.purchasePartyDisplayName,
        );
        if (nameCompare != 0) return nameCompare;
        return a.sectionCode.compareTo(b.sectionCode);
      });

    return builtRows;
  }

  String _normalizeBusinessName(String value) {
    var text = value.toUpperCase().trim();
    text = text.replaceAll('&', ' AND ');
    text = text.replaceAll(RegExp(r'[^A-Z0-9 ]'), ' ');
    text = text.replaceAll(RegExp(r'\s+'), ' ').trim();

    if (text.isEmpty) return '';

    final tokens = text
        .split(' ')
        .where((token) => token.isNotEmpty)
        .where((token) => !_legalSuffixTokens.contains(token))
        .toList();

    return tokens.join(' ');
  }

  List<String> _tokenizeBusinessName(String value) {
    final normalized = _normalizeBusinessName(value);
    if (normalized.isEmpty) return const <String>[];

    return normalized
        .split(' ')
        .where((token) => token.isNotEmpty)
        .where((token) => !_ignoredNameTokens.contains(token))
        .toList();
  }

  Set<String> _resolveTargetPans(String mappedName) {
    final exactPans = widget.tdsPartyPans[mappedName];
    if (exactPans != null) {
      return exactPans
          .map((pan) => normalizePan(pan))
          .where((pan) => pan.isNotEmpty)
          .toSet();
    }

    final normalizedMappedName = normalizeName(mappedName.trim());
    for (final entry in widget.tdsPartyPans.entries) {
      if (normalizeName(entry.key) != normalizedMappedName) continue;
      return entry.value
          .map((pan) => normalizePan(pan))
          .where((pan) => pan.isNotEmpty)
          .toSet();
    }

    return const <String>{};
  }

  List<TdsPartyCandidate> _buildTdsCandidates() {
    return uniqueTdsParties
        .map(
          (partyName) => TdsPartyCandidate(
            partyName: partyName,
            normalizedName: _normalizeBusinessName(partyName),
            tokens: _tokenizeBusinessName(partyName),
            pans: _resolveTargetPans(partyName),
          ),
        )
        .toList()
      ..sort((a, b) => a.partyName.compareTo(b.partyName));
  }

  String _getPanForTdsParty(String? mappedName) {
    if (mappedName == null || mappedName.trim().isEmpty) return '';

    final pans = _resolveTargetPans(mappedName);
    if (pans.isEmpty) return '';
    if (pans.length == 1) return pans.first;

    return 'Multiple PANs';
  }

  String _getPanForSelection(SellerMappingRowVm row, String? selectedValue) {
    if (_isSeparateSelection(row, selectedValue)) {
      return row.purchasePan;
    }
    return _getPanForTdsParty(selectedValue);
  }

  String? _normalizeToKnownTdsParty(String? mappedName) {
    if (mappedName == null || mappedName.trim().isEmpty) return null;

    final trimmed = mappedName.trim();
    if (uniqueTdsParties.contains(trimmed)) {
      return trimmed;
    }

    final normalized = normalizeName(trimmed);
    for (final party in uniqueTdsParties) {
      if (normalizeName(party) == normalized) {
        return party;
      }
    }

    return null;
  }

  bool _hasPanConflict({
    required String purchasePan,
    required Set<String> candidatePans,
  }) {
    if (purchasePan.isEmpty || candidatePans.isEmpty) return false;
    return !candidatePans.contains(purchasePan);
  }

  double _levenshteinSimilarity(String a, String b) {
    if (a.isEmpty || b.isEmpty) return 0.0;
    if (a == b) return 1.0;

    final m = a.length;
    final n = b.length;
    final dp = List.generate(m + 1, (_) => List<int>.filled(n + 1, 0));

    for (var i = 0; i <= m; i++) {
      dp[i][0] = i;
    }
    for (var j = 0; j <= n; j++) {
      dp[0][j] = j;
    }

    for (var i = 1; i <= m; i++) {
      for (var j = 1; j <= n; j++) {
        final cost = a[i - 1] == b[j - 1] ? 0 : 1;
        dp[i][j] = math.min(
          math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1),
          dp[i - 1][j - 1] + cost,
        );
      }
    }

    final maxLength = math.max(m, n);
    return maxLength == 0 ? 1.0 : 1.0 - (dp[m][n] / maxLength);
  }

  double _tokenOverlapScore(List<String> left, List<String> right) {
    if (left.isEmpty || right.isEmpty) return 0.0;

    final leftSet = left.toSet();
    final rightSet = right.toSet();
    final overlap = leftSet.intersection(rightSet).length;
    final maxCount = math.max(leftSet.length, rightSet.length);
    if (maxCount == 0) return 0.0;

    return overlap / maxCount;
  }

  double _combinedNameScore({
    required String normalizedPurchaseName,
    required List<String> purchaseTokens,
    required TdsPartyCandidate candidate,
  }) {
    final charScore = _levenshteinSimilarity(
      normalizedPurchaseName,
      candidate.normalizedName,
    );
    final tokenScore = _tokenOverlapScore(purchaseTokens, candidate.tokens);
    return (charScore * 0.45) + (tokenScore * 0.55);
  }

  bool _isStrongTokenMatch(
    List<String> purchaseTokens,
    List<String> candidateTokens,
  ) {
    if (purchaseTokens.isEmpty || candidateTokens.isEmpty) return false;

    final purchaseSet = purchaseTokens.toSet();
    final candidateSet = candidateTokens.toSet();
    final overlap = purchaseSet.intersection(candidateSet).length;
    if (overlap < 2) return false;

    final purchaseCoverage = overlap / purchaseSet.length;
    final candidateCoverage = overlap / candidateSet.length;
    return purchaseCoverage >= 0.8 && candidateCoverage >= 0.8;
  }

  bool _isStrongPanCandidate({
    required String normalizedPurchaseName,
    required List<String> purchaseTokens,
    required TdsPartyCandidate candidate,
  }) {
    if (candidate.normalizedName.isEmpty) return false;
    if (candidate.normalizedName == normalizedPurchaseName) return true;
    if (_isStrongTokenMatch(purchaseTokens, candidate.tokens)) return true;

    return _combinedNameScore(
          normalizedPurchaseName: normalizedPurchaseName,
          purchaseTokens: purchaseTokens,
          candidate: candidate,
        ) >=
        0.92;
  }

  List<CandidateScore> _rankCandidatesByName({
    required SellerMappingRowVm row,
    required List<TdsPartyCandidate> candidates,
  }) {
    final normalizedPurchaseName = _normalizeBusinessName(
      row.purchasePartyDisplayName,
    );
    final purchaseTokens = _tokenizeBusinessName(row.purchasePartyDisplayName);
    final purchasePan = normalizePan(row.purchasePan);

    final ranked = candidates
        .where(
          (candidate) => !_hasPanConflict(
            purchasePan: purchasePan,
            candidatePans: candidate.pans,
          ),
        )
        .map(
          (candidate) => CandidateScore(
            candidate: candidate,
            score: _combinedNameScore(
              normalizedPurchaseName: normalizedPurchaseName,
              purchaseTokens: purchaseTokens,
              candidate: candidate,
            ),
          ),
        )
        .toList();

    ranked.sort((a, b) {
      final byScore = b.score.compareTo(a.score);
      if (byScore != 0) return byScore;
      return a.candidate.partyName.compareTo(b.candidate.partyName);
    });

    return ranked;
  }

  AutoMapDecision _resolveAutoMapForRow(
    SellerMappingRowVm row,
    List<TdsPartyCandidate> candidates,
  ) {
    final purchasePan = normalizePan(row.purchasePan);
    final normalizedPurchaseName = _normalizeBusinessName(
      row.purchasePartyDisplayName,
    );
    final purchaseTokens = _tokenizeBusinessName(row.purchasePartyDisplayName);

    TdsPartyCandidate? candidateByName(String mappedName) {
      for (final candidate in candidates) {
        if (candidate.partyName == mappedName) return candidate;
      }
      return null;
    }

    AutoMapDecision? evaluateSavedMapping(
      SellerMapping? mapping,
      String reason,
      double confidence,
    ) {
      if (mapping == null) return null;

      final mappedName = mapping.mappedName.trim();
      if (mappedName.isEmpty || !uniqueTdsParties.contains(mappedName)) {
        return null;
      }

      final candidate = candidateByName(mappedName);
      if (candidate == null) return null;

      if (_hasPanConflict(
        purchasePan: purchasePan,
        candidatePans: candidate.pans,
      )) {
        return const AutoMapDecision(
          autoMapReason: 'pan_conflict_blocked',
          autoMapConfidence: 0.0,
          blockedByPanConflict: true,
        );
      }

      return AutoMapDecision(
        autoMapReason: reason,
        autoMapConfidence: confidence,
        selectedCandidate: mappedName,
      );
    }

    final exactSavedDecision = evaluateSavedMapping(
      row.exactMapping,
      'saved_mapping_exact',
      0.99,
    );
    if (exactSavedDecision != null) return exactSavedDecision;

    final fallbackSavedDecision = evaluateSavedMapping(
      row.fallbackMapping,
      'saved_mapping_fallback',
      0.95,
    );
    if (fallbackSavedDecision != null) return fallbackSavedDecision;

    if (purchasePan.isNotEmpty) {
      final samePanCandidates =
          candidates
              .where((candidate) => candidate.pans.contains(purchasePan))
              .toList()
            ..sort((a, b) => a.partyName.compareTo(b.partyName));

      final strongSamePanCandidates = samePanCandidates
          .where(
            (candidate) => _isStrongPanCandidate(
              normalizedPurchaseName: normalizedPurchaseName,
              purchaseTokens: purchaseTokens,
              candidate: candidate,
            ),
          )
          .toList();

      if (strongSamePanCandidates.length == 1) {
        return AutoMapDecision(
          autoMapReason: 'exact_pan_match',
          autoMapConfidence: 1.0,
          selectedCandidate: strongSamePanCandidates.first.partyName,
        );
      }

      if (strongSamePanCandidates.length > 1) {
        return const AutoMapDecision(
          autoMapReason: 'ambiguous_candidate',
          autoMapConfidence: 0.0,
          ambiguous: true,
        );
      }
    }

    final exactNameCandidates =
        candidates
            .where((candidate) => candidate.normalizedName.isNotEmpty)
            .where(
              (candidate) => candidate.normalizedName == normalizedPurchaseName,
            )
            .toList()
          ..sort((a, b) => a.partyName.compareTo(b.partyName));

    if (exactNameCandidates.length == 1) {
      return AutoMapDecision(
        autoMapReason: 'normalized_name_exact',
        autoMapConfidence: purchasePan.isEmpty ? 0.93 : 0.96,
        selectedCandidate: exactNameCandidates.first.partyName,
      );
    }

    if (exactNameCandidates.length > 1) {
      return const AutoMapDecision(
        autoMapReason: 'ambiguous_candidate',
        autoMapConfidence: 0.0,
        ambiguous: true,
      );
    }

    final strongTokenCandidates =
        candidates
            .where(
              (candidate) =>
                  _isStrongTokenMatch(purchaseTokens, candidate.tokens),
            )
            .toList()
          ..sort((a, b) => a.partyName.compareTo(b.partyName));

    if (strongTokenCandidates.length == 1) {
      return AutoMapDecision(
        autoMapReason: 'strong_token_match',
        autoMapConfidence: purchasePan.isEmpty ? 0.88 : 0.91,
        selectedCandidate: strongTokenCandidates.first.partyName,
      );
    }

    if (strongTokenCandidates.length > 1) {
      return const AutoMapDecision(
        autoMapReason: 'ambiguous_candidate',
        autoMapConfidence: 0.0,
        ambiguous: true,
      );
    }

    if (purchasePan.isEmpty) {
      return const AutoMapDecision(
        autoMapReason: 'no_safe_match',
        autoMapConfidence: 0.0,
      );
    }

    final rankedCandidates = _rankCandidatesByName(
      row: row,
      candidates: candidates,
    );
    if (rankedCandidates.isEmpty) {
      return const AutoMapDecision(
        autoMapReason: 'no_safe_match',
        autoMapConfidence: 0.0,
      );
    }

    final best = rankedCandidates.first;
    final second = rankedCandidates.length > 1 ? rankedCandidates[1] : null;
    final bestScore = best.score;
    final secondScore = second?.score ?? 0.0;
    final scoreGap = bestScore - secondScore;

    if (bestScore >= 0.94 && scoreGap >= 0.05) {
      return AutoMapDecision(
        autoMapReason: 'fuzzy_name_match',
        autoMapConfidence: bestScore,
        selectedCandidate: best.candidate.partyName,
      );
    }

    if (bestScore >= 0.9 && scoreGap < 0.05) {
      return const AutoMapDecision(
        autoMapReason: 'ambiguous_candidate',
        autoMapConfidence: 0.0,
        ambiguous: true,
      );
    }

    return const AutoMapDecision(
      autoMapReason: 'no_safe_match',
      autoMapConfidence: 0.0,
    );
  }

  String _getStatus({
    required SellerMappingRowVm row,
    required String? selectedValue,
  }) {
    if (_isPreflightMode &&
        selectedValue != null &&
        _isSeparateSelection(row, selectedValue)) {
      return 'Marked Separate';
    }

    if (row.is26QUnmatched) {
      return '26Q Unmatched';
    }

    if (selectedValue == null || selectedValue.trim().isEmpty) {
      if (row.isPurchaseOnly) {
        return 'Purchase Only';
      }
      if (_isPreflightMode &&
          row.requiresDangerousReview &&
          row.preflightReasonLabel.trim().isNotEmpty) {
        return row.preflightReasonLabel.trim();
      }
      return 'Unmapped';
    }

    final purchasePan = normalizePan(row.purchasePan);
    final targetPan = _getPanForSelection(row, selectedValue);

    if (purchasePan.isEmpty ||
        targetPan.isEmpty ||
        targetPan == 'Multiple PANs') {
      return 'Mapped (PAN missing)';
    }

    if (purchasePan == targetPan) {
      return 'Mapped';
    }

    return 'PAN Conflict';
  }

  bool _isDangerousPreflightStatus(String status) {
    return status == 'Conflicting PAN' ||
        status == 'Ambiguous Identity' ||
        status == 'Unresolved Identity';
  }

  String _statusChipLabel(String status) {
    if (status == 'Conflicting PAN' ||
        status == 'Ambiguous Identity' ||
        status == 'Unresolved Identity') {
      return 'Needs Review';
    }
    return status;
  }

  String? _getExplicitSelectedValue(SellerMappingRowVm row) {
    if (_clearedRowKeys.contains(row.rowKey)) {
      return null;
    }

    final selectedValue = selectedMappings[row.rowKey];
    if (selectedValue == null) {
      return null;
    }
    if (_isSeparateSelection(row, selectedValue)) {
      return selectedValue;
    }
    if (!uniqueTdsParties.contains(selectedValue)) {
      selectedMappings.remove(row.rowKey);
      return null;
    }
    return selectedValue;
  }

  String? _getResolvedSuggestionValue(SellerMappingRowVm row) {
    if (_clearedRowKeys.contains(row.rowKey)) {
      return null;
    }

    if (_isPreflightMode && row.requiresDangerousReview) {
      return null;
    }

    return _normalizeToKnownTdsParty(row.resolvedSuggestion?.mappedName);
  }

  String? _getSelectedValue(SellerMappingRowVm row) {
    return _getExplicitSelectedValue(row) ?? _getResolvedSuggestionValue(row);
  }

  bool get _usesGlobalPreflightNeedsActionScope =>
      _isPreflightMode && _activeListView == SellerMappingListView.needsAction;

  List<SellerMappingRowVm> _rowsForCurrentViewScope() {
    if (_usesGlobalPreflightNeedsActionScope) {
      return _rowsForSection(_allSectionsAuditCode);
    }
    return _rowsForActiveSection();
  }

  bool _isDangerousRowExplicitlyResolved(SellerMappingRowVm row) {
    if (!_isPreflightMode ||
        row.isPurchaseOnly ||
        !row.requiresDangerousReview) {
      return false;
    }

    final explicitSelectedValue = _getExplicitSelectedValue(row);
    if (explicitSelectedValue == null || explicitSelectedValue.trim().isEmpty) {
      return false;
    }
    if (_isSeparateSelection(row, explicitSelectedValue)) {
      return true;
    }

    final selectedPan = _getPanForSelection(row, explicitSelectedValue);
    if (selectedPan == 'Multiple PANs') {
      return false;
    }

    final status = _getStatus(row: row, selectedValue: explicitSelectedValue);
    return status != 'PAN Conflict' && !_isDangerousPreflightStatus(status);
  }

  bool _isUnresolvedDangerousPreflightRow(SellerMappingRowVm row) {
    if (!_isPreflightMode ||
        row.isPurchaseOnly ||
        !row.requiresDangerousReview) {
      return false;
    }
    return !_isDangerousRowExplicitlyResolved(row);
  }

  List<SellerMappingRowVm> _filteredRows() {
    if (_cachedFilteredRows != null) return _cachedFilteredRows!;

    final stopwatch = Stopwatch()..start();
    final query = _searchQuery.trim().toUpperCase();
    final activeRows = _rowsForCurrentViewScope();

    _cachedFilteredRows = activeRows.where((row) {
      final selectedValue = _getSelectedValue(row);
      final selectedPan = _getPanForSelection(row, selectedValue);
      final status = _getStatus(row: row, selectedValue: selectedValue);
      final autoMapDetail = autoMapDetails[row.rowKey];

      if (!_matchesListView(
        row: row,
        status: status,
        selectedValue: selectedValue,
        autoMapDetail: autoMapDetail,
        view: _activeListView,
      )) {
        return false;
      }

      final matchesStatus = _statusFilter == 'All' || status == _statusFilter;
      if (!matchesStatus) return false;

      if (query.isEmpty) return true;

      final searchHaystack = <String>[
        row.purchasePartyDisplayName,
        row.purchasePan,
        row.sectionCode,
        selectedValue ?? '',
        selectedPan,
        autoMapDetail?.autoMapReason ?? '',
        row.fallbackMapping?.mappedName ?? '',
        row.fallbackMapping?.mappedPan ?? '',
        row.resolvedSuggestion?.mappedName ?? '',
        row.resolvedSuggestion?.mappedPan ?? '',
        row.resolvedSuggestion?.helperText ?? '',
        row.is26QUnmatched ? '26Q Unmatched' : '',
        row.isAboveThreshold ? 'Above Threshold' : 'Below Threshold',
        widget.blockedAliases.contains(row.normalizedAlias)
            ? 'Blocked Alias'
            : '',
      ].join(' ').toUpperCase();

      return searchHaystack.contains(query);
    }).toList();
    stopwatch.stop();
    debugPrint('SELLER MAP PERF filterMs=${stopwatch.elapsedMilliseconds}');
    return _cachedFilteredRows!;
  }

  List<_SellerMappingDisplayRow> _buildDisplayRows(
    List<SellerMappingRowVm> visibleRows,
  ) {
    final stopwatch = Stopwatch()..start();
    final rows = <_SellerMappingDisplayRow>[];
    var expandedCount = 0;

    for (var index = 0; index < visibleRows.length; index++) {
      final row = visibleRows[index];
      final selectedValue = _getSelectedValue(row);
      final selectedPan = _getPanForSelection(row, selectedValue);
      final status = _getStatus(row: row, selectedValue: selectedValue);
      final autoMapDetail = autoMapDetails[row.rowKey];
      final isExpanded = _isRowExpanded(row.rowKey);
      if (isExpanded) {
        expandedCount += 1;
      }

      rows.add(
        _SellerMappingDisplayRow(
          row: row,
          selectedValue: selectedValue,
          selectedPan: selectedPan,
          status: status,
          autoMapDetail: autoMapDetail,
          helperMessages: isExpanded
              ? _helperMessages(
                  row: row,
                  status: status,
                  selectedValue: selectedValue,
                )
              : const <String>[],
          index: index,
          isLast: index == visibleRows.length - 1,
          isExpanded: isExpanded,
        ),
      );
    }

    stopwatch.stop();
    debugPrint('SELLER MAP ROW BUILD ms=${stopwatch.elapsedMilliseconds}');
    debugPrint('SELLER MAP EXPANDED ROWS count=$expandedCount');
    return rows;
  }

  void _applyAutoMap() {
    final candidates = _buildTdsCandidates();
    final nextDetails = Map<String, AutoMapDecision>.from(autoMapDetails);
    final activeRows = _rowsForActiveSection();

    setState(() {
      for (final row in activeRows) {
        if (row.isReadOnly) continue;
        if (widget.blockedAliases.contains(row.normalizedAlias)) continue;
        if (selectedMappings.containsKey(row.rowKey)) continue;

        final decision = _resolveAutoMapForRow(row, candidates);
        nextDetails[row.rowKey] = decision;

        final targetName = decision.selectedCandidate?.trim() ?? '';
        if (targetName.isEmpty) continue;
        _clearedRowKeys.remove(row.rowKey);
        selectedMappings[row.rowKey] = targetName;
      }

      autoMapDetails = nextDetails;
      _invalidateViewCaches();
    });
  }

  void _clearVisibleMappings() {
    final visibleRows = _filteredRows();
    setState(() {
      for (final row in visibleRows) {
        if (row.isReadOnly) continue;
        _clearedRowKeys.add(row.rowKey);
        selectedMappings.remove(row.rowKey);
        autoMapDetails.remove(row.rowKey);
      }
      _invalidateViewCaches(resetPage: true);
    });
  }

  void _clearMapping(SellerMappingRowVm row) {
    if (row.isReadOnly) return;
    setState(() {
      _clearedRowKeys.add(row.rowKey);
      selectedMappings.remove(row.rowKey);
      autoMapDetails.remove(row.rowKey);
      _invalidateViewCaches();
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_firstFrameLogged) return;
      _firstFrameLogged = true;
      debugPrint(
        'SELLER SCREEN PERF => firstFrame ms=${_screenOpenStopwatch.elapsedMilliseconds}',
      );
      _hydrateScreenAfterFirstFrame();
    });
  }

  Future<void> _hydrateScreenAfterFirstFrame() async {
    await Future<void>.delayed(Duration.zero);
    final prepareWatch = Stopwatch()..start();
    final preparedState = _prepareInitialState();
    prepareWatch.stop();
    debugPrint(
      'SELLER SCREEN PERF => prepareInput ms=${prepareWatch.elapsedMilliseconds}',
    );

    final buildWatch = Stopwatch()..start();
    final isolatePayload = preparedState.toIsolatePayload();
    final payload = _shouldUseComputeForViewModels
        ? await compute(_buildSellerScreenViewModelsInIsolate, isolatePayload)
        : _buildSellerScreenViewModelsInIsolate(isolatePayload);
    buildWatch.stop();
    debugPrint(
      'SELLER SCREEN PERF => buildViewModels ms=${buildWatch.elapsedMilliseconds}',
    );

    if (!mounted) return;

    final readyState = _SellerMappingScreenReadyState.fromIsolatePayload(
      Map<String, dynamic>.from(payload),
    );

    setState(() {
      uniqueTdsParties = preparedState.uniqueTdsParties;
      _rowDataBySection = preparedState.rowDataBySection;
      _exactMappingsByKey = preparedState.exactMappingsByKey;
      _fallbackMappingsByAlias = preparedState.fallbackMappingsByAlias;
      _mappingRowsBySectionCache
        ..clear()
        ..addAll(readyState.mappingRowsBySection);
      selectedMappings = readyState.selectedMappings;
      autoMapDetails = <String, AutoMapDecision>{};
      _activeSectionCode = readyState.activeSectionCode;
      _isInitializing = false;
      _invalidateViewCaches(resetPage: true);
    });

    final filterWatch = Stopwatch()..start();
    _filteredRows();
    filterWatch.stop();
    debugPrint(
      'SELLER SCREEN PERF => applyFilters ms=${filterWatch.elapsedMilliseconds}',
    );
  }

  _SellerMappingScreenPreparedState _prepareInitialState() {
    final uniqueTdsParties =
        widget.tdsParties
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .toSet()
            .toList()
          ..sort();

    final exactMappingsByKey = <String, SellerMapping>{};
    final fallbackMappingsByAlias = <String, SellerMapping>{};

    for (final mapping in widget.existingMappings) {
      final aliasKey = normalizeName(mapping.aliasName.trim());
      final sectionCode = normalizeSellerMappingSectionCode(
        mapping.sectionCode,
      );
      if (aliasKey.isEmpty || mapping.mappedName.trim().isEmpty) continue;

      if (sectionCode == _allSectionsAuditCode) {
        fallbackMappingsByAlias[aliasKey] = mapping;
        continue;
      }

      exactMappingsByKey[_rowKey(aliasKey, sectionCode)] = mapping;
    }

    final rowDataBySection = <String, List<SellerMappingScreenRowData>>{
      for (final section in _sectionTabOrder)
        section: <SellerMappingScreenRowData>[],
    };

    for (final row in widget.purchaseRows) {
      final sectionCode = normalizeSellerMappingSectionCode(row.sectionCode);
      rowDataBySection.putIfAbsent(
        sectionCode,
        () => <SellerMappingScreenRowData>[],
      );
      rowDataBySection[sectionCode]!.add(row);
    }

    return _SellerMappingScreenPreparedState(
      buyerPan: widget.buyerPan,
      selectedSectionLabel: widget.selectedSectionLabel,
      isPreflightMode: _isPreflightMode,
      uniqueTdsParties: uniqueTdsParties,
      rowDataBySection: rowDataBySection,
      exactMappingsByKey: exactMappingsByKey,
      fallbackMappingsByAlias: fallbackMappingsByAlias,
    );
  }

  bool get _shouldUseComputeForViewModels =>
      !Platform.environment.containsKey('FLUTTER_TEST');

  @override
  void dispose() {
    _searchDebounce?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  void _saveMappings() {
    final upserts = <Map<String, String>>[];
    final deleted = <Map<String, String>>[];
    final rowsToPersist = _mappingRowsBySectionCache.values
        .expand((rows) => rows)
        .toList();
    final dangerousRows = <String, SellerMappingRowVm>{};

    for (final row in rowsToPersist) {
      if (_isPreflightMode &&
          row.requiresDangerousReview &&
          !row.isPurchaseOnly) {
        dangerousRows[row.rowKey] = row;
      }

      if (row.isReadOnly) {
        continue;
      }
      final currentMappedName = selectedMappings[row.rowKey]?.trim() ?? '';
      final resolvedSuggestionName =
          _normalizeToKnownTdsParty(
            row.resolvedSuggestion?.mappedName,
          )?.trim() ??
          '';
      final shouldPersistSuggestionFallback =
          _isPreflightMode && !row.requiresDangerousReview;
      final effectiveMappedName = currentMappedName.isNotEmpty
          ? currentMappedName
          : (shouldPersistSuggestionFallback ? resolvedSuggestionName : '');
      final existingExactName = row.exactMapping?.mappedName.trim() ?? '';

      if (effectiveMappedName.isEmpty) {
        if (existingExactName.isNotEmpty &&
            _clearedRowKeys.contains(row.rowKey)) {
          deleted.add({
            'aliasName': row.normalizedAlias,
            'sectionCode': row.sectionCode,
          });
        }
        continue;
      }

      // In preflight mode, always upsert mapped rows so that the upload
      // screen's next preflight refresh sees the section-level saved alias
      // and suppresses any stale dangerous flags.
      if (effectiveMappedName == existingExactName && !_isPreflightMode) {
        continue;
      }

      upserts.add({
        'aliasName': row.normalizedAlias,
        'sectionCode': row.sectionCode,
        'mappedName': effectiveMappedName,
        'mappedPan': _isSeparateSelection(row, effectiveMappedName)
            ? row.purchasePan
            : _getPanForTdsParty(effectiveMappedName),
      });
    }

    final dangerousRowCount = dangerousRows.length;
    final dangerousSuggestionOnlyCount = dangerousRows.values.where((row) {
      if (_isDangerousRowExplicitlyResolved(row)) return false;
      final suggested = _normalizeToKnownTdsParty(
        row.resolvedSuggestion?.mappedName,
      );
      return suggested != null && suggested.trim().isNotEmpty;
    }).length;
    final dangerousExplicitlyResolvedCount = dangerousRows.values
        .where(_isDangerousRowExplicitlyResolved)
        .length;
    final dangerousRemaining = dangerousRows.values
        .where((row) => !_isDangerousRowExplicitlyResolved(row))
        .length;

    debugPrint(
      'SELLER MAP PREFLIGHT STATE dangerousRows=$dangerousRowCount '
      'dangerousSuggestionOnly=$dangerousSuggestionOnlyCount '
      'dangerousExplicitlyResolved=$dangerousExplicitlyResolvedCount '
      'dangerousRemaining=$dangerousRemaining',
    );

    Navigator.pop(
      context,
      SellerMappingScreenResult(
        upserts: upserts,
        deleted: deleted,
        dangerousRemaining: dangerousRemaining,
      ),
    );
  }

  String _buyerInitials() {
    final segments = widget.buyerName
        .trim()
        .split(RegExp(r'\s+'))
        .where((segment) => segment.isNotEmpty)
        .toList();
    if (segments.isEmpty) return 'BA';
    if (segments.length == 1) {
      return segments.first.substring(0, 1).toUpperCase();
    }
    return (segments.first.substring(0, 1) + segments.last.substring(0, 1))
        .toUpperCase();
  }

  List<SellerMappingSummaryMetric> _buildSummaryMetrics() {
    final visibleRows = _filteredRows();
    var mapped = 0;
    var unmapped = 0;
    var conflicts = 0;
    var verifyPan = 0;

    for (final row in visibleRows) {
      final selectedValue = _getSelectedValue(row);
      final status = _getStatus(row: row, selectedValue: selectedValue);
      if (selectedValue != null && selectedValue.trim().isNotEmpty) {
        mapped++;
      }
      if (status == 'Unmapped') unmapped++;
      if (status == 'PAN Conflict') conflicts++;
      if (status == 'Mapped (PAN missing)') verifyPan++;
    }

    return [
      SellerMappingSummaryMetric(
        label: _activeListView == SellerMappingListView.allSellers
            ? 'Total'
            : 'Visible',
        value: visibleRows.length,
        icon: Icons.inventory_2_outlined,
        color: const Color(0xFF344054),
      ),
      SellerMappingSummaryMetric(
        label: 'Mapped',
        value: mapped,
        icon: Icons.link_rounded,
        color: SellerMappingTheme.successColor,
      ),
      SellerMappingSummaryMetric(
        label: 'Unmapped',
        value: unmapped,
        icon: Icons.hourglass_empty_rounded,
        color: SellerMappingTheme.warningColor,
      ),
      SellerMappingSummaryMetric(
        label: 'Conflicts',
        value: conflicts,
        icon: Icons.warning_amber_rounded,
        color: SellerMappingTheme.dangerColor,
      ),
      SellerMappingSummaryMetric(
        label: '26Q Unmatched',
        value: visibleRows.where((row) => row.is26QUnmatched).length,
        icon: Icons.link_off_rounded,
        color: const Color(0xFF7C3AED),
      ),
      SellerMappingSummaryMetric(
        label: 'Verify PAN',
        value: verifyPan,
        icon: Icons.rule_folder_outlined,
        color: SellerMappingTheme.warningColor,
      ),
    ];
  }

  AppStatusBadgeTone _statusTone(String status) {
    switch (status) {
      case 'Mapped':
        return AppStatusBadgeTone.success;
      case 'Marked Separate':
        return AppStatusBadgeTone.info;
      case 'Purchase Only':
        return AppStatusBadgeTone.neutral;
      case '26Q Unmatched':
        return AppStatusBadgeTone.warning;
      case 'Conflicting PAN':
      case 'Ambiguous Identity':
      case 'Unresolved Identity':
      case 'Mapped (PAN missing)':
        return status == 'Mapped (PAN missing)'
            ? AppStatusBadgeTone.warning
            : AppStatusBadgeTone.danger;
      case 'PAN Conflict':
        return AppStatusBadgeTone.danger;
      default:
        return AppStatusBadgeTone.neutral;
    }
  }

  IconData _statusIconSafe(String status) {
    switch (status) {
      case 'Mapped':
        return Icons.check_circle_rounded;
      case 'Marked Separate':
        return Icons.account_tree_rounded;
      case 'Purchase Only':
        return Icons.store_outlined;
      case '26Q Unmatched':
        return Icons.link_off_rounded;
      case 'Conflicting PAN':
        return Icons.warning_rounded;
      case 'Ambiguous Identity':
        return Icons.help_center_rounded;
      case 'Unresolved Identity':
        return Icons.person_off_rounded;
      case 'Mapped (PAN missing)':
        return Icons.help_outline_rounded;
      case 'PAN Conflict':
        return Icons.error_outline_rounded;
      default:
        return Icons.radio_button_unchecked_rounded;
    }
  }

  Color _rowBackgroundColorSafe({required String status, required int index}) {
    final base = index.isEven ? Colors.white : const Color(0xFFFBFCFE);
    if (status == 'PAN Conflict' ||
        status == 'Conflicting PAN' ||
        status == 'Ambiguous Identity' ||
        status == 'Unresolved Identity') {
      return Color.alphaBlend(
        SellerMappingTheme.dangerColor.withValues(alpha: 0.08),
        base,
      );
    }
    if (status == '26Q Unmatched') {
      return Color.alphaBlend(
        const Color(0xFF7C3AED).withValues(alpha: 0.08),
        base,
      );
    }
    if (status == 'Purchase Only') {
      return Color.alphaBlend(
        const Color(0xFF64748B).withValues(alpha: 0.05),
        base,
      );
    }
    if (status == 'Mapped (PAN missing)') {
      return Color.alphaBlend(
        SellerMappingTheme.warningColor.withValues(alpha: 0.08),
        base,
      );
    }
    return base;
  }

  List<String> _helperMessages({
    required SellerMappingRowVm row,
    required String status,
    required String? selectedValue,
  }) {
    if (_clearedRowKeys.contains(row.rowKey) &&
        (selectedValue == null || selectedValue.trim().isEmpty)) {
      return const <String>[];
    }

    final messages = <String>[];
    final autoMapDetail = autoMapDetails[row.rowKey];
    final fallbackName = row.fallbackMapping?.mappedName.trim() ?? '';
    final suggestion = row.resolvedSuggestion;
    final explicitSelectedValue = _getExplicitSelectedValue(row);

    if (explicitSelectedValue != null && autoMapDetail == null) {
      if (_isDangerousPreflightStatus(status)) {
        messages.add('Review this saved selection before reconciliation');
      } else if (status == 'Unmapped') {
        messages.add('Select a 26Q party for this alias and section');
      }
    }

    if (autoMapDetail != null) {
      switch (autoMapDetail.autoMapReason) {
        case 'saved_mapping_exact':
          messages.add('Auto-mapped from saved exact mapping');
          break;
        case 'saved_mapping_fallback':
          messages.add('Auto-mapped from saved fallback');
          break;
        case 'exact_pan_match':
          messages.add('Auto-mapped from exact PAN');
          break;
        case 'normalized_name_exact':
          messages.add('Auto-mapped from exact name');
          break;
        case 'strong_token_match':
          messages.add('Auto-mapped from strong token match');
          break;
        case 'fuzzy_name_match':
          messages.add('Auto-mapped from conservative fuzzy match');
          break;
        case 'pan_conflict_blocked':
          messages.add('Auto-map blocked due to PAN conflict');
          break;
        case 'ambiguous_candidate':
          messages.add('Auto-map found multiple close candidates');
          break;
        case 'no_safe_match':
          messages.add('No safe auto-map candidate found');
          break;
      }
    }

    if (suggestion != null &&
        suggestion.mappedName.trim().isNotEmpty &&
        explicitSelectedValue == null) {
      switch (suggestion.source) {
        case 'tds_only':
          messages.add(
            '26Q seller is currently unmatched to any purchase alias',
          );
          break;
        case 'saved_exact':
        case 'saved_fallback':
        case 'backend_inferred':
        case 'preflight_resolved':
          break;
      }
      if (_isDangerousPreflightStatus(status) ||
          status == 'Unmapped' ||
          status == '26Q Unmatched') {
        messages.add(
          suggestion.helperText.trim().isNotEmpty
              ? suggestion.helperText.trim()
              : 'Visible as a suggestion only; save to store as exact section mapping',
        );
      }
    }

    if (status == '26Q Unmatched') {
      messages.add('Review the 26Q-only seller and link it manually if needed');
    } else if (status == 'Marked Separate') {
      messages.add('This seller will stay separate from 26Q after saving');
    } else if (_isPreflightMode &&
        row.preflightReasonDetail.trim().isNotEmpty &&
        _isDangerousPreflightStatus(status)) {
      messages.add(row.preflightReasonDetail.trim());
    } else if (status == 'PAN Conflict') {
      messages.add('Conflict: purchase PAN and 26Q PAN differ');
      if (explicitSelectedValue == null) {
        messages.add('Please Mark Separate or select a valid party');
      }
    } else if (status == 'Mapped (PAN missing)') {
      messages.add('Mapping exists, but PAN still needs manual verification');
    } else if (status == 'Unmapped') {
      if (fallbackName.isNotEmpty) {
        messages.add('Global fallback mapping available');
      } else {
        messages.add('Select a 26Q party for this alias and section');
      }
    } else if (selectedValue != null &&
        selectedValue.isNotEmpty &&
        _isDangerousPreflightStatus(status)) {
      messages.add('PAN verified against selected 26Q party');
    }

    if (fallbackName.isNotEmpty &&
        (row.exactMapping?.mappedName.trim() ?? '').isEmpty &&
        !messages.contains('Global fallback mapping available') &&
        (status == 'Unmapped' || _isDangerousPreflightStatus(status))) {
      messages.add('Global fallback mapping available');
    }

    return messages.take(2).toList();
  }

  Color _helperTextColor({
    required String status,
    required AutoMapDecision? autoMapDetail,
  }) {
    if (status == '26Q Unmatched') {
      return const Color(0xFF6D28D9);
    }
    if (status == 'PAN Conflict' ||
        autoMapDetail?.blockedByPanConflict == true) {
      return SellerMappingTheme.dangerColor;
    }
    if (status == 'Mapped (PAN missing)' || autoMapDetail?.ambiguous == true) {
      return SellerMappingTheme.warningColor;
    }
    if (autoMapDetail?.selectedCandidate != null ||
        rowHasResolvedSuggestion(status, autoMapDetail) ||
        status == 'Mapped') {
      return const Color(0xFF335C9E);
    }
    return SellerMappingTheme.mutedTextColor;
  }

  bool rowHasResolvedSuggestion(String status, AutoMapDecision? autoMapDetail) {
    return autoMapDetail == null &&
        (status == 'Mapped' || status == 'Mapped (PAN missing)');
  }

  int _hiddenSummaryRowCount() {
    if (_activeListView != SellerMappingListView.needsAction) {
      return 0;
    }

    return _rowsForCurrentViewScope().length -
        _filteredRowsForViewModeOnly().length;
  }

  List<SellerMappingRowVm> _filteredRowsForViewModeOnly() {
    return _rowsForCurrentViewScope().where((row) {
      final selectedValue = _getSelectedValue(row);
      final status = _getStatus(row: row, selectedValue: selectedValue);
      final autoMapDetail = autoMapDetails[row.rowKey];

      return _matchesListView(
        row: row,
        status: status,
        selectedValue: selectedValue,
        autoMapDetail: autoMapDetail,
        view: _activeListView,
      );
    }).toList();
  }

  String? _viewModeHelperText() {
    if (_activeListView != SellerMappingListView.needsAction) {
      return null;
    }

    final hiddenRows = _hiddenSummaryRowCount();
    if (hiddenRows <= 0) {
      return null;
    }

    return '$hiddenRows non-actionable seller rows are hidden in Needs Action.';
  }

  Widget _buildHeader() {
    final selectedSection = _usesGlobalPreflightNeedsActionScope
        ? 'All Sellers (Needs Action)'
        : _activeSectionCode == _allSectionsAuditCode
        ? 'All Sellers (Audit)'
        : sectionDisplayLabel(_activeSectionCode);
    final fyLabel = widget.financialYearLabel.trim().isEmpty
        ? 'All FY'
        : widget.financialYearLabel.trim();
    final metrics = _buildSummaryMetrics();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      decoration: BoxDecoration(
        color: SellerMappingTheme.surfaceColor,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: SellerMappingTheme.borderColor),
        boxShadow: const [
          BoxShadow(
            color: Color(0x120F172A),
            blurRadius: 26,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          IconButton.filledTonal(
            onPressed: () => Navigator.maybePop(context),
            style: IconButton.styleFrom(
              backgroundColor: SellerMappingTheme.primarySoft,
              foregroundColor: SellerMappingTheme.primaryColor,
            ),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
          const SizedBox(width: 16),
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(
                colors: [Color(0xFF4A6CF7), Color(0xFF2744C7)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            alignment: Alignment.center,
            child: Text(
              _buyerInitials(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Seller Mapping',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: SellerMappingTheme.primaryColor,
                    letterSpacing: 0.2,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  widget.buyerName.trim().isEmpty
                      ? 'Unnamed Buyer'
                      : widget.buyerName.trim(),
                  style: const TextStyle(
                    fontSize: 24,
                    height: 1.15,
                    fontWeight: FontWeight.w800,
                    color: SellerMappingTheme.titleTextColor,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    SellerMappingPill(
                      icon: Icons.badge_outlined,
                      label: widget.buyerPan.trim().isEmpty
                          ? 'PAN unavailable'
                          : widget.buyerPan.trim().toUpperCase(),
                    ),
                    SellerMappingPill(
                      icon: Icons.calendar_today_outlined,
                      label: fyLabel,
                    ),
                    SellerMappingPill(
                      icon: Icons.tune_rounded,
                      label: selectedSection,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  _isPreflightMode
                      ? 'Preflight includes both purchase-register and 26Q sellers for this section to ensure complete visibility.'
                      : 'Rows remain section-aware. Existing ALL mappings are shown as guidance only, and saving continues to create or update exact section mappings.',
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.45,
                    color: SellerMappingTheme.mutedTextColor,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 24),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            alignment: WrapAlignment.end,
            children: metrics
                .map((metric) => SellerMappingMetricCard(metric: metric))
                .toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildTopToolbar() {
    final buttonStyle = OutlinedButton.styleFrom(
      minimumSize: const Size(0, 46),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      side: const BorderSide(color: SellerMappingTheme.borderColor),
      foregroundColor: SellerMappingTheme.titleTextColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
    );
    final viewModeHelperText = _viewModeHelperText();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: SellerMappingTheme.surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: SellerMappingTheme.borderColor),
      ),
      child: Wrap(
        spacing: 12,
        runSpacing: 12,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Seller View',
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                  color: SellerMappingTheme.mutedTextColor,
                ),
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: SellerMappingListView.values.map((view) {
                  final isSelected = _activeListView == view;
                  final count = _listViewCounts()[view] ?? 0;
                  return ChoiceChip(
                    label: Text('${view.label} ($count)'),
                    selected: isSelected,
                    onSelected: (_) {
                      setState(() {
                        _activeListView = view;
                        _invalidateViewCaches(resetPage: true);
                      });
                    },
                    selectedColor: SellerMappingTheme.primarySoft,
                    backgroundColor: Colors.white,
                    side: BorderSide(
                      color: isSelected
                          ? const Color(0xFFBFCCF5)
                          : SellerMappingTheme.borderColor,
                    ),
                    labelStyle: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: isSelected
                          ? SellerMappingTheme.primaryColor
                          : SellerMappingTheme.titleTextColor,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(999),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _availableSectionCodes.map((sectionCode) {
                  final isSelected = _activeSectionCode == sectionCode;
                  final label = sectionCode == _allSectionsAuditCode
                      ? 'All Sellers'
                      : sectionDisplayLabel(sectionCode);
                  return ChoiceChip(
                    label: Text(label),
                    selected: isSelected,
                    onSelected: (_) {
                      if (_activeSectionCode == sectionCode) return;
                      setState(() {
                        _activeSectionCode = sectionCode;
                        _invalidateViewCaches(resetPage: true);
                      });
                    },
                    selectedColor: SellerMappingTheme.primarySoft,
                    backgroundColor: Colors.white,
                    side: BorderSide(
                      color: isSelected
                          ? const Color(0xFFBFCCF5)
                          : SellerMappingTheme.borderColor,
                    ),
                    labelStyle: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: isSelected
                          ? SellerMappingTheme.primaryColor
                          : SellerMappingTheme.titleTextColor,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(999),
                    ),
                  );
                }).toList(),
              ),
              if (viewModeHelperText != null) ...[
                const SizedBox(height: 8),
                SizedBox(
                  width: 320,
                  child: Text(
                    viewModeHelperText,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: SellerMappingTheme.mutedTextColor,
                    ),
                  ),
                ),
              ],
            ],
          ),
          SizedBox(
            width: 360,
            child: TextField(
              controller: _searchController,
              onChanged: (value) {
                if (_searchDebounce?.isActive ?? false) {
                  _searchDebounce!.cancel();
                }
                _searchDebounce = Timer(const Duration(milliseconds: 250), () {
                  setState(() {
                    _searchQuery = value;
                    _invalidateViewCaches(resetPage: true);
                  });
                });
              },
              decoration: InputDecoration(
                hintText: 'Search party, PAN, section or mapped 26Q party',
                prefixIcon: const Icon(Icons.search_rounded, size: 18),
                suffixIcon: _searchQuery.isEmpty
                    ? null
                    : IconButton(
                        tooltip: 'Clear search',
                        onPressed: () {
                          _searchController.clear();
                          setState(() {
                            _searchQuery = '';
                            _invalidateViewCaches(resetPage: true);
                          });
                        },
                        icon: const Icon(Icons.close_rounded),
                      ),
                filled: true,
                fillColor: const Color(0xFFF8FAFC),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 11,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                    color: SellerMappingTheme.borderColor,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                    color: SellerMappingTheme.borderColor,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                    color: SellerMappingTheme.primaryColor,
                    width: 1.2,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            width: 190,
            child: AppCompactSelectField(
              value: _statusFilter,
              labelText: 'Status',
              options: const [
                'All',
                'Mapped',
                'Unmapped',
                'Mapped (PAN missing)',
                'PAN Conflict',
                '26Q Unmatched',
              ],
              onChanged: (value) {
                setState(() {
                  _statusFilter = value;
                  _invalidateViewCaches(resetPage: true);
                });
              },
            ),
          ),
          OutlinedButton.icon(
            onPressed: _applyAutoMap,
            style: buttonStyle.copyWith(
              foregroundColor: WidgetStatePropertyAll(
                SellerMappingTheme.primaryColor,
              ),
              side: const WidgetStatePropertyAll(
                BorderSide(color: Color(0xFFBFCCF5)),
              ),
              backgroundColor: const WidgetStatePropertyAll(
                SellerMappingTheme.primarySoft,
              ),
            ),
            icon: const Icon(Icons.auto_fix_high_rounded),
            label: const Text('Auto Map'),
          ),
          OutlinedButton.icon(
            onPressed: _clearVisibleMappings,
            style: buttonStyle.copyWith(
              foregroundColor: const WidgetStatePropertyAll(
                SellerMappingTheme.dangerColor,
              ),
              side: WidgetStatePropertyAll(
                BorderSide(
                  color: SellerMappingTheme.dangerColor.withValues(alpha: 0.28),
                ),
              ),
            ),
            icon: const Icon(Icons.layers_clear_rounded),
            label: const Text('Clear Mapping'),
          ),
          FilledButton.icon(
            onPressed: _saveMappings,
            style: FilledButton.styleFrom(
              minimumSize: const Size(0, 46),
              padding: const EdgeInsets.symmetric(horizontal: 18),
              backgroundColor: SellerMappingTheme.primaryColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              textStyle: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
              ),
            ),
            icon: const Icon(Icons.save_outlined),
            label: const Text('Save Mapping'),
          ),
        ],
      ),
    );
  }

  Widget _buildTableHeader() {
    Widget headerCell(
      String title,
      int flex, {
      Alignment? alignment,
      String? tooltipMessage,
    }) {
      return Expanded(
        flex: flex,
        child: Align(
          alignment: alignment ?? Alignment.centerLeft,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF344054),
                    letterSpacing: 0.3,
                  ),
                ),
              ),
              if (tooltipMessage != null &&
                  tooltipMessage.trim().isNotEmpty) ...[
                const SizedBox(width: 4),
                Tooltip(
                  message: tooltipMessage,
                  child: const Icon(
                    Icons.info_outline_rounded,
                    size: 14,
                    color: SellerMappingTheme.mutedTextColor,
                  ),
                ),
              ],
            ],
          ),
        ),
      );
    }

    const sourcePanTooltip =
        'PAN from source file, or inferred from GSTIN when available.';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: const BoxDecoration(
        color: Color(0xFFF8FAFC),
        border: Border(
          bottom: BorderSide(color: SellerMappingTheme.borderColor),
        ),
      ),
      child: Row(
        children: [
          headerCell(_isPreflightMode ? 'Source Seller' : 'Purchase Party', 4),
          headerCell('Section', 2),
          headerCell(
            _isPreflightMode ? 'Source/Inferred PAN' : 'Purchase PAN',
            2,
            tooltipMessage: _isPreflightMode ? sourcePanTooltip : null,
          ),
          headerCell(
            _isPreflightMode
                ? 'Matched / Selected 26Q Seller'
                : 'Mapped 26Q Party',
            4,
          ),
          headerCell('26Q PAN', 2),
          headerCell('Status', 2),
          headerCell(
            'Actions',
            _isPreflightMode ? 2 : 1,
            alignment: Alignment.center,
          ),
        ],
      ),
    );
  }

  void _setMappedParty(SellerMappingRowVm row, String? value) {
    if (row.isReadOnly) return;
    setState(() {
      autoMapDetails.remove(row.rowKey);
      final normalizedValue = _normalizeToKnownTdsParty(value)?.trim() ?? '';
      if (normalizedValue.isEmpty) {
        _clearedRowKeys.add(row.rowKey);
        selectedMappings.remove(row.rowKey);
      } else {
        _clearedRowKeys.remove(row.rowKey);
        selectedMappings[row.rowKey] = normalizedValue;
      }
      _invalidateViewCaches();
    });
  }

  bool _canAcceptSuggestion(SellerMappingRowVm row) {
    if (_getExplicitSelectedValue(row) != null) return false;

    final suggested = _normalizeToKnownTdsParty(
      row.resolvedSuggestion?.mappedName,
    );
    if (suggested == null || suggested.trim().isEmpty) return false;

    final statusIfAccepted = _getStatus(row: row, selectedValue: suggested);
    if (_isDangerousPreflightStatus(statusIfAccepted)) return false;

    return true;
  }

  void _acceptSuggestedMapping(SellerMappingRowVm row) {
    final suggested = _normalizeToKnownTdsParty(
      row.resolvedSuggestion?.mappedName,
    );
    if (suggested == null || suggested.trim().isEmpty) return;
    _setMappedParty(row, suggested);
  }

  void _markSeparate(SellerMappingRowVm row) {
    if (row.isReadOnly) return;
    setState(() {
      autoMapDetails.remove(row.rowKey);
      _clearedRowKeys.remove(row.rowKey);
      selectedMappings[row.rowKey] = _separateSelectionValue(row);
      _invalidateViewCaches();
    });
  }

  Widget _buildPartyAutocomplete({
    required SellerMappingRowVm row,
    required String? selectedValue,
  }) {
    if (row.isReadOnly) {
      final displayValue = selectedValue?.trim().isNotEmpty == true
          ? selectedValue!.trim()
          : 'No purchase alias linked';
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: SellerMappingTheme.borderColor),
        ),
        child: Text(
          displayValue,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: SellerMappingTheme.titleTextColor,
          ),
        ),
      );
    }

    return AppSearchAutocompleteField(
      key: ValueKey('${row.rowKey}|${selectedValue ?? ''}'),
      value: selectedValue ?? '',
      options: uniqueTdsParties,
      hintText: 'Search 26Q party or PAN...',
      allowFreeText: false,
      maxVisibleOptions: 8,
      optionsMaxHeight: 340,
      searchableTermsBuilder: (option) => <String>[
        option,
        _getPanForTdsParty(option),
      ],
      optionSubtitleBuilder: (option) {
        final pan = _getPanForTdsParty(option);
        return pan.isEmpty ? 'PAN not available' : 'PAN: $pan';
      },
      decoration: InputDecoration(
        hintText: 'Select 26Q party',
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 12,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: SellerMappingTheme.borderColor),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: SellerMappingTheme.borderColor),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(
            color: SellerMappingTheme.primaryColor,
            width: 1.2,
          ),
        ),
      ),
      onChanged: (value) {
        if (value.trim().isEmpty) {
          _setMappedParty(row, null);
          return;
        }

        final exactMatch = _normalizeToKnownTdsParty(value);
        if (exactMatch != null) {
          _setMappedParty(row, exactMatch);
        }
      },
      onSelected: (value) => _setMappedParty(row, value),
    );
  }

  String _summarySelectionLabel(SellerMappingRowVm row, String? selectedValue) {
    if (_isSeparateSelection(row, selectedValue)) {
      return 'Marked Separate';
    }
    final normalizedSelected = selectedValue?.trim() ?? '';
    if (normalizedSelected.isNotEmpty) {
      return normalizedSelected;
    }

    final suggestion = row.resolvedSuggestion?.mappedName.trim() ?? '';
    if (suggestion.isNotEmpty) {
      return suggestion;
    }

    return row.isReadOnly ? 'No purchase alias linked' : 'No suggestion';
  }

  Widget _buildTableRow({required _SellerMappingDisplayRow rowView}) {
    final row = rowView.row;
    final selectedValue = rowView.selectedValue;
    final selectedPan = rowView.selectedPan;
    final status = rowView.status;
    final helperMessages = rowView.helperMessages;
    final autoMapDetail = rowView.autoMapDetail;
    final isExpanded = rowView.isExpanded;

    Widget cell({
      required int flex,
      required Widget child,
      Alignment alignment = Alignment.centerLeft,
    }) {
      return Expanded(
        flex: flex,
        child: Align(alignment: alignment, child: child),
      );
    }

    final actionChild = isExpanded
        ? (_isPreflightMode
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (_canAcceptSuggestion(row))
                      TextButton(
                        onPressed: row.isReadOnly
                            ? null
                            : () => _acceptSuggestedMapping(row),
                        style: TextButton.styleFrom(
                          minimumSize: const Size(0, 32),
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        child: const Text('Use Suggested Match'),
                      ),
                    if (!_isSeparateSelection(row, selectedValue))
                      TextButton(
                        onPressed: row.isReadOnly
                            ? null
                            : () => _markSeparate(row),
                        style: TextButton.styleFrom(
                          minimumSize: const Size(0, 32),
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        child: const Text('Separate'),
                      ),
                    IconButton(
                      tooltip: row.isReadOnly
                          ? '26Q-only row cannot be cleared here'
                          : 'Clear Seller Mapping',
                      onPressed: row.isReadOnly
                          ? null
                          : () => _clearMapping(row),
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.white.withValues(alpha: 0.88),
                        foregroundColor: SellerMappingTheme.dangerColor,
                        minimumSize: const Size(32, 32),
                        padding: const EdgeInsets.all(6),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(
                            color: SellerMappingTheme.dangerColor.withValues(
                              alpha: 0.18,
                            ),
                          ),
                        ),
                      ),
                      icon: const Icon(Icons.close_rounded),
                    ),
                    TextButton(
                      onPressed: () => _toggleRowExpanded(row.rowKey),
                      style: TextButton.styleFrom(
                        minimumSize: const Size(0, 32),
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: const Text('Done'),
                    ),
                  ],
                )
              : IconButton(
                  tooltip: row.isReadOnly
                      ? '26Q-only row cannot be cleared here'
                      : 'Clear Seller Mapping',
                  onPressed: row.isReadOnly ? null : () => _clearMapping(row),
                  style: IconButton.styleFrom(
                    backgroundColor: Colors.white.withValues(alpha: 0.88),
                    foregroundColor: SellerMappingTheme.dangerColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(
                        color: SellerMappingTheme.dangerColor.withValues(
                          alpha: 0.18,
                        ),
                      ),
                    ),
                  ),
                  icon: const Icon(Icons.close_rounded),
                ))
        : OutlinedButton.icon(
            onPressed: () => _toggleRowExpanded(row.rowKey),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(0, 36),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            icon: const Icon(Icons.expand_more_rounded, size: 18),
            label: Text(row.isReadOnly ? 'View' : 'Review'),
          );

    return AnimatedContainer(
      duration: const Duration(milliseconds: 160),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: BoxDecoration(
        color: _rowBackgroundColorSafe(status: status, index: rowView.index),
        border: Border(
          bottom: BorderSide(
            color: rowView.isLast
                ? SellerMappingTheme.borderColor
                : const Color(0xFFE8EEF8),
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          cell(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                row.purchasePartyDisplayName,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 13,
                  height: 1.35,
                  fontWeight: FontWeight.w700,
                  color: SellerMappingTheme.titleTextColor,
                ),
              ),
            ),
          ),
          cell(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.only(top: 2),
              child: SellerMappingPill(
                icon: Icons.grid_view_rounded,
                label: sectionDisplayLabel(row.sectionCode),
                compact: true,
              ),
            ),
          ),
          cell(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                row.purchasePan.isEmpty ? 'Not available' : row.purchasePan,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 13,
                  height: 1.35,
                  color: SellerMappingTheme.titleTextColor,
                ),
              ),
            ),
          ),
          cell(
            flex: 4,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (isExpanded)
                  _buildPartyAutocomplete(
                    row: row,
                    selectedValue: selectedValue,
                  )
                else
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      _summarySelectionLabel(row, selectedValue),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        height: 1.35,
                        fontWeight: FontWeight.w600,
                        color: SellerMappingTheme.titleTextColor,
                      ),
                    ),
                  ),
                if (helperMessages.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      helperMessages.join('\n'),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        height: 1.2,
                        fontWeight: FontWeight.w600,
                        color: _helperTextColor(
                          status: status,
                          autoMapDetail: autoMapDetail,
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          cell(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                selectedPan.isEmpty ? 'Not available' : selectedPan,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 13,
                  height: 1.35,
                  color: SellerMappingTheme.titleTextColor,
                ),
              ),
            ),
          ),
          cell(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.only(top: 1),
              child: SellerMappingStatusChip(
                icon: _statusIconSafe(status),
                label: _statusChipLabel(status),
                tone: _statusTone(status),
              ),
            ),
          ),
          cell(
            flex: _isPreflightMode ? 2 : 1,
            alignment: Alignment.topCenter,
            child: actionChild,
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    final showNeedsActionState =
        _isPreflightMode &&
        _activeListView == SellerMappingListView.needsAction &&
        _searchQuery.trim().isEmpty &&
        _statusFilter == 'All';

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(36),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: SellerMappingTheme.primarySoft,
                borderRadius: BorderRadius.circular(22),
              ),
              alignment: Alignment.center,
              child: const Icon(
                Icons.manage_search_rounded,
                size: 34,
                color: SellerMappingTheme.primaryColor,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              showNeedsActionState
                  ? 'No sellers currently need action'
                  : 'No seller rows match the current filters',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: SellerMappingTheme.titleTextColor,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              showNeedsActionState
                  ? 'Needs Action is empty right now. Switch views only if you want to inspect additional sellers.'
                  : 'Try clearing search or switching the status filter to see more mapping rows.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13,
                height: 1.45,
                color: SellerMappingTheme.mutedTextColor,
              ),
            ),
            const SizedBox(height: 18),
            TextButton.icon(
              onPressed: () {
                _searchController.clear();
                setState(() {
                  _searchQuery = '';
                  _statusFilter = 'All';
                  _invalidateViewCaches(resetPage: true);
                });
              },
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Clear Search and Filters'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTableSection(List<_SellerMappingDisplayRow> visibleRows) {
    return Container(
      decoration: BoxDecoration(
        color: SellerMappingTheme.surfaceColor,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: SellerMappingTheme.borderColor),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F0F172A),
            blurRadius: 20,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: visibleRows.isEmpty
            ? _buildEmptyState()
            : LayoutBuilder(
                builder: (context, constraints) {
                  final tableWidth = math.max(constraints.maxWidth, 1180.0);
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SizedBox(
                      width: tableWidth,
                      child: Column(
                        children: [
                          _buildTableHeader(),
                          Expanded(
                            child: ListView.builder(
                              padding: EdgeInsets.zero,
                              itemCount: visibleRows.length,
                              itemBuilder: (context, index) {
                                return _buildTableRow(
                                  rowView: visibleRows[index],
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }

  Widget _buildBottomBar(List<SellerMappingRowVm> visibleRows) {
    final visibleCount = visibleRows.length;
    final totalCount = _rowsForCurrentViewScope().length;
    final conflictCount = visibleRows.where((row) {
      final selectedValue = _getSelectedValue(row);
      return _getStatus(row: row, selectedValue: selectedValue) ==
          'PAN Conflict';
    }).length;
    final missingPanCount = visibleRows.where((row) {
      final selectedValue = _getSelectedValue(row);
      return _getStatus(row: row, selectedValue: selectedValue) ==
          'Mapped (PAN missing)';
    }).length;

    final summaryText = visibleCount == totalCount
        ? 'Showing all $totalCount seller rows.'
        : 'Showing $visibleCount of $totalCount seller rows.';

    final reviewText = conflictCount > 0
        ? '$conflictCount conflict ${conflictCount == 1 ? 'needs' : 'need'} review before final reconciliation.'
        : missingPanCount > 0
        ? '$missingPanCount row ${missingPanCount == 1 ? 'has' : 'have'} mapped selections that still need PAN verification.'
        : 'All visible mappings are ready for reconciliation review.';
    final preflightReviewCount = visibleRows.where((row) {
      return _isUnresolvedDangerousPreflightRow(row);
    }).length;

    final reviewColor = conflictCount > 0
        ? SellerMappingTheme.dangerColor
        : missingPanCount > 0
        ? SellerMappingTheme.warningColor
        : SellerMappingTheme.successColor;

    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(24, 14, 24, 18),
        decoration: BoxDecoration(
          color: SellerMappingTheme.surfaceColor.withValues(alpha: 0.96),
          border: const Border(
            top: BorderSide(color: SellerMappingTheme.borderColor),
          ),
          boxShadow: const [
            BoxShadow(
              color: Color(0x140F172A),
              blurRadius: 24,
              offset: Offset(0, -8),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    summaryText,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: SellerMappingTheme.titleTextColor,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _isPreflightMode
                        ? (preflightReviewCount > 0
                              ? '$preflightReviewCount 26Q seller ${preflightReviewCount == 1 ? 'still needs' : 'still need'} dangerous identity review before reconciliation.'
                              : 'No dangerous 26Q seller identity issues remain in preflight review.')
                        : reviewText,
                    style: TextStyle(
                      fontSize: 12.5,
                      height: 1.35,
                      fontWeight: FontWeight.w600,
                      color: reviewColor,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            OutlinedButton.icon(
              onPressed: () => Navigator.maybePop(context),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(0, 46),
                padding: const EdgeInsets.symmetric(horizontal: 18),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                side: const BorderSide(color: SellerMappingTheme.borderColor),
              ),
              icon: const Icon(Icons.arrow_back_rounded),
              label: const Text('Back to Upload'),
            ),
            const SizedBox(width: 12),
            FilledButton.icon(
              onPressed: _saveMappings,
              style: FilledButton.styleFrom(
                minimumSize: const Size(0, 46),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                backgroundColor: SellerMappingTheme.primaryColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              icon: const Icon(Icons.arrow_forward_rounded),
              label: Text(
                _isPreflightMode ? 'Save Review' : 'Proceed to Reconciliation',
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool _matchesListView({
    required SellerMappingRowVm row,
    required String status,
    required String? selectedValue,
    required AutoMapDecision? autoMapDetail,
    required SellerMappingListView view,
  }) {
    if (_isPreflightMode) {
      final needsAction = _isUnresolvedDangerousPreflightRow(row);

      switch (view) {
        case SellerMappingListView.needsAction:
          return needsAction;
        case SellerMappingListView.aboveThreshold:
          return false;
        case SellerMappingListView.unmatched26Q:
          return row.is26QUnmatched;
        case SellerMappingListView.allSellers:
          return true;
      }
    }

    final isBlockedAlias = widget.blockedAliases.contains(row.normalizedAlias);
    final wasCleared = _clearedRowKeys.contains(row.rowKey);
    final isUnmapped = selectedValue == null || selectedValue.trim().isEmpty;
    final hasPanIssue =
        status == 'PAN Conflict' ||
        status == 'Mapped (PAN missing)' ||
        row.hasMissingOrUncertainPan ||
        row.hasNameOrPanConflict ||
        autoMapDetail?.blockedByPanConflict == true ||
        autoMapDetail?.ambiguous == true;
    final hasManualMappingIssue = isBlockedAlias || wasCleared;
    final needsAction =
        row.is26QUnmatched ||
        hasManualMappingIssue ||
        row.hasReconciliationMismatch ||
        hasPanIssue ||
        ((row.isAboveThreshold || row.hasApplicableTdsImpact) && isUnmapped);

    switch (view) {
      case SellerMappingListView.needsAction:
        return needsAction;
      case SellerMappingListView.aboveThreshold:
        return row.isAboveThreshold || row.hasApplicableTdsImpact;
      case SellerMappingListView.unmatched26Q:
        return row.is26QUnmatched;
      case SellerMappingListView.allSellers:
        return true;
    }
  }

  Map<SellerMappingListView, int> _listViewCounts() {
    if (_cachedListViewCounts != null) return _cachedListViewCounts!;
    final counts = <SellerMappingListView, int>{
      for (final view in SellerMappingListView.values) view: 0,
    };
    for (final view in SellerMappingListView.values) {
      final rowsForView =
          _isPreflightMode && view == SellerMappingListView.needsAction
          ? _rowsForSection(_allSectionsAuditCode)
          : _rowsForActiveSection();
      for (final row in rowsForView) {
        final selectedValue = _getSelectedValue(row);
        final status = _getStatus(row: row, selectedValue: selectedValue);
        final autoMapDetail = autoMapDetails[row.rowKey];
        if (_matchesListView(
          row: row,
          status: status,
          selectedValue: selectedValue,
          autoMapDetail: autoMapDetail,
          view: view,
        )) {
          counts[view] = (counts[view] ?? 0) + 1;
        }
      }
    }
    _cachedListViewCounts = counts;
    return counts;
  }

  @override
  Widget build(BuildContext context) {
    if (_isInitializing) {
      return _buildLoadingScaffold();
    }

    final allFiltered = _filteredRows();
    final visibleCount = math.min(_visibleRowLimit, allFiltered.length);
    final visibleRows = allFiltered.isNotEmpty
        ? allFiltered.sublist(0, visibleCount)
        : <SellerMappingRowVm>[];
    final pagedRowViews = _buildDisplayRows(visibleRows);

    final stopwatch = Stopwatch()..start();

    final body = Scaffold(
      backgroundColor: SellerMappingTheme.pageBackground,
      bottomNavigationBar: _buildBottomBar(allFiltered),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
          child: Column(
            children: [
              _buildHeader(),
              const SizedBox(height: 14),
              _buildTopToolbar(),
              const SizedBox(height: 16),
              Expanded(child: _buildTableSection(pagedRowViews)),
              if (visibleCount < allFiltered.length)
                _buildLoadMore(allFiltered),
            ],
          ),
        ),
      ),
    );

    stopwatch.stop();
    debugPrint(
      'SELLER MAP PERF pageMs=${stopwatch.elapsedMilliseconds} rowsRendered=${visibleRows.length}',
    );

    return body;
  }

  Widget _buildLoadMore(List<SellerMappingRowVm> allFiltered) {
    final remaining = math.max(allFiltered.length - _visibleRowLimit, 0);
    final nextLoadCount = math.min(_visibleRowIncrement, remaining);

    return Padding(
      padding: const EdgeInsets.only(top: 12.0),
      child: Column(
        children: [
          Text(
            'Showing ${math.min(_visibleRowLimit, allFiltered.length)} of ${allFiltered.length} seller rows.',
            style: const TextStyle(
              fontWeight: FontWeight.w600,
              color: SellerMappingTheme.mutedTextColor,
            ),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () {
              setState(() {
                _visibleRowLimit += _visibleRowIncrement;
              });
            },
            icon: const Icon(Icons.expand_more_rounded),
            label: Text(
              nextLoadCount > 0 ? 'Load More ($nextLoadCount)' : 'Load More',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingScaffold() {
    return Scaffold(
      backgroundColor: SellerMappingTheme.pageBackground,
      body: SafeArea(
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
            decoration: BoxDecoration(
              color: SellerMappingTheme.surfaceColor,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: SellerMappingTheme.borderColor),
            ),
            child: const Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(strokeWidth: 2.6),
                ),
                SizedBox(height: 16),
                Text(
                  'Preparing seller mapping review...',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: SellerMappingTheme.titleTextColor,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SellerMappingScreenPreparedState {
  final String buyerPan;
  final String selectedSectionLabel;
  final bool isPreflightMode;
  final List<String> uniqueTdsParties;
  final Map<String, List<SellerMappingScreenRowData>> rowDataBySection;
  final Map<String, SellerMapping> exactMappingsByKey;
  final Map<String, SellerMapping> fallbackMappingsByAlias;

  const _SellerMappingScreenPreparedState({
    required this.buyerPan,
    required this.selectedSectionLabel,
    required this.isPreflightMode,
    required this.uniqueTdsParties,
    required this.rowDataBySection,
    required this.exactMappingsByKey,
    required this.fallbackMappingsByAlias,
  });

  Map<String, dynamic> toIsolatePayload() {
    return {
      'buyerPan': buyerPan,
      'selectedSectionLabel': selectedSectionLabel,
      'isPreflightMode': isPreflightMode,
      'uniqueTdsParties': uniqueTdsParties,
      'rowDataBySection': {
        for (final entry in rowDataBySection.entries)
          entry.key: entry.value.map(_serializeScreenRowForIsolate).toList(),
      },
      'exactMappingsByKey': {
        for (final entry in exactMappingsByKey.entries)
          entry.key: _serializeSellerMappingForIsolate(entry.value),
      },
      'fallbackMappingsByAlias': {
        for (final entry in fallbackMappingsByAlias.entries)
          entry.key: _serializeSellerMappingForIsolate(entry.value),
      },
    };
  }
}

class _SellerMappingScreenReadyState {
  final Map<String, List<SellerMappingRowVm>> mappingRowsBySection;
  final Map<String, String> selectedMappings;
  final String activeSectionCode;

  const _SellerMappingScreenReadyState({
    required this.mappingRowsBySection,
    required this.selectedMappings,
    required this.activeSectionCode,
  });

  factory _SellerMappingScreenReadyState.fromIsolatePayload(
    Map<String, dynamic> payload,
  ) {
    final mappingRowsBySection = <String, List<SellerMappingRowVm>>{};
    final rawMappingRows = Map<String, dynamic>.from(
      payload['mappingRowsBySection'] as Map? ?? const {},
    );
    for (final entry in rawMappingRows.entries) {
      mappingRowsBySection[entry.key] = List<Map<String, dynamic>>.from(
        entry.value as List? ?? const [],
      ).map(_deserializeRowVmForIsolate).toList();
    }

    return _SellerMappingScreenReadyState(
      mappingRowsBySection: mappingRowsBySection,
      selectedMappings: Map<String, String>.from(
        payload['selectedMappings'] as Map? ?? const {},
      ),
      activeSectionCode: payload['activeSectionCode'] as String? ?? '194Q',
    );
  }
}

Map<String, dynamic> _buildSellerScreenViewModelsInIsolate(
  Map<String, dynamic> payload,
) {
  final buyerPan = payload['buyerPan'] as String? ?? '';
  final selectedSectionLabel = payload['selectedSectionLabel'] as String? ?? '';
  final isPreflightMode = payload['isPreflightMode'] as bool? ?? false;
  final uniqueTdsParties = List<String>.from(
    payload['uniqueTdsParties'] as List? ?? const <String>[],
  );

  final rowDataBySection = <String, List<SellerMappingScreenRowData>>{};
  final rawRowDataBySection = Map<String, dynamic>.from(
    payload['rowDataBySection'] as Map? ?? const {},
  );
  for (final entry in rawRowDataBySection.entries) {
    rowDataBySection[entry.key] = List<Map<String, dynamic>>.from(
      entry.value as List? ?? const [],
    ).map(_deserializeScreenRowForIsolate).toList();
  }

  final exactMappingsByKey = <String, SellerMapping>{};
  final rawExactMappings = Map<String, dynamic>.from(
    payload['exactMappingsByKey'] as Map? ?? const {},
  );
  for (final entry in rawExactMappings.entries) {
    exactMappingsByKey[entry.key] = _deserializeSellerMappingForIsolate(
      Map<String, dynamic>.from(entry.value as Map),
    );
  }

  final fallbackMappingsByAlias = <String, SellerMapping>{};
  final rawFallbackMappings = Map<String, dynamic>.from(
    payload['fallbackMappingsByAlias'] as Map? ?? const {},
  );
  for (final entry in rawFallbackMappings.entries) {
    fallbackMappingsByAlias[entry.key] = _deserializeSellerMappingForIsolate(
      Map<String, dynamic>.from(entry.value as Map),
    );
  }

  final availableSectionCodes = _availableSectionCodesForIsolate(
    rowDataBySection: rowDataBySection,
  );
  final selectedMappings = <String, String>{};
  final mappingRowsBySection = <String, List<SellerMappingRowVm>>{};

  for (final sectionCode in availableSectionCodes) {
    mappingRowsBySection[sectionCode] = _buildRowsForSectionInIsolate(
      buyerPan: buyerPan,
      sectionCode: sectionCode,
      rowDataBySection: rowDataBySection,
      exactMappingsByKey: exactMappingsByKey,
      fallbackMappingsByAlias: fallbackMappingsByAlias,
    );
  }

  for (final sectionCode in availableSectionCodes) {
    if (sectionCode == _SellerMappingScreenState._allSectionsAuditCode) {
      continue;
    }
    for (final row in mappingRowsBySection[sectionCode] ?? const []) {
      final hydratedValue =
          _normalizeToKnownTdsPartyForIsolate(
            uniqueTdsParties,
            row.exactMapping?.mappedName,
          ) ??
          _normalizeToKnownTdsPartyForIsolate(
            uniqueTdsParties,
            row.fallbackMapping?.mappedName,
          );
      if (hydratedValue == null || hydratedValue.trim().isEmpty) continue;
      selectedMappings[row.rowKey] = hydratedValue.trim();
    }
  }

  final preferredSection = normalizeSellerMappingSectionCode(
    selectedSectionLabel.trim(),
  );
  final fallbackSection = availableSectionCodes.firstWhere(
    (sectionCode) =>
        sectionCode != _SellerMappingScreenState._allSectionsAuditCode,
    orElse: () =>
        availableSectionCodes.isNotEmpty ? availableSectionCodes.first : '194Q',
  );
  final canUsePreferredSection =
      availableSectionCodes.contains(preferredSection) &&
      (!isPreflightMode ||
          preferredSection != _SellerMappingScreenState._allSectionsAuditCode ||
          _hasNeedsActionRowsForSectionInIsolate(
            rows:
                mappingRowsBySection[_SellerMappingScreenState
                    ._allSectionsAuditCode] ??
                const [],
            selectedMappings: selectedMappings,
          ));

  return {
    'mappingRowsBySection': {
      for (final entry in mappingRowsBySection.entries)
        entry.key: entry.value.map(_serializeRowVmForIsolate).toList(),
    },
    'selectedMappings': selectedMappings,
    'activeSectionCode': canUsePreferredSection
        ? preferredSection
        : fallbackSection,
  };
}

List<String> _availableSectionCodesForIsolate({
  required Map<String, List<SellerMappingScreenRowData>> rowDataBySection,
}) {
  final presentSections = _SellerMappingScreenState._sectionTabOrder
      .where((section) => (rowDataBySection[section] ?? const []).isNotEmpty)
      .toList();
  if (presentSections.length > 1) {
    return <String>[
      ...presentSections,
      _SellerMappingScreenState._allSectionsAuditCode,
    ];
  }
  return presentSections;
}

List<SellerMappingRowVm> _buildRowsForSectionInIsolate({
  required String buyerPan,
  required String sectionCode,
  required Map<String, List<SellerMappingScreenRowData>> rowDataBySection,
  required Map<String, SellerMapping> exactMappingsByKey,
  required Map<String, SellerMapping> fallbackMappingsByAlias,
}) {
  final sourceRows =
      sectionCode == _SellerMappingScreenState._allSectionsAuditCode
      ? _SellerMappingScreenState._sectionTabOrder
            .expand((section) => rowDataBySection[section] ?? const [])
            .toList()
      : List<SellerMappingScreenRowData>.from(
          rowDataBySection[sectionCode] ?? const [],
        );

  final rowMap = <String, SellerMappingRowVm>{};
  for (final row in sourceRows) {
    final aliasKey = normalizeName(row.normalizedAlias.trim());
    final normalizedSection = normalizeSellerMappingSectionCode(
      row.sectionCode,
    );
    if (aliasKey.isEmpty) continue;

    final exactMappingKey =
        '${normalizePan(buyerPan)}|$aliasKey|$normalizedSection';
    final existing = rowMap['$aliasKey|$normalizedSection'];
    final displayName = row.purchasePartyDisplayName.trim();
    final purchasePan = normalizePan(row.purchasePan);

    rowMap['$aliasKey|$normalizedSection'] = SellerMappingRowVm(
      purchasePartyDisplayName: displayName.isNotEmpty
          ? displayName
          : (existing?.purchasePartyDisplayName ?? ''),
      normalizedAlias: aliasKey,
      sectionCode: normalizedSection,
      purchasePan: purchasePan.isNotEmpty
          ? purchasePan
          : (existing?.purchasePan ?? ''),
      purchaseGstNo: row.purchaseGstNo.trim().isNotEmpty
          ? row.purchaseGstNo.trim()
          : (existing?.purchaseGstNo ?? ''),
      exactMapping:
          exactMappingsByKey[exactMappingKey] ?? existing?.exactMapping,
      fallbackMapping:
          fallbackMappingsByAlias[aliasKey] ?? existing?.fallbackMapping,
      resolvedSuggestion:
          row.resolvedSuggestion ?? existing?.resolvedSuggestion,
      isReadOnly: row.isReadOnly || (existing?.isReadOnly ?? false),
      isAboveThreshold:
          row.isAboveThreshold || (existing?.isAboveThreshold ?? false),
      hasReconciliationMismatch:
          row.hasReconciliationMismatch ||
          (existing?.hasReconciliationMismatch ?? false),
      hasNameOrPanConflict:
          row.hasNameOrPanConflict || (existing?.hasNameOrPanConflict ?? false),
      hasApplicableTdsImpact:
          row.hasApplicableTdsImpact ||
          (existing?.hasApplicableTdsImpact ?? false),
      is26QUnmatched: row.is26QUnmatched || (existing?.is26QUnmatched ?? false),
      hasMissingOrUncertainPan:
          row.hasMissingOrUncertainPan ||
          (existing?.hasMissingOrUncertainPan ?? false),
      preflightReasonCode: row.preflightReasonCode.trim().isNotEmpty
          ? row.preflightReasonCode.trim()
          : (existing?.preflightReasonCode ?? ''),
      preflightReasonLabel: row.preflightReasonLabel.trim().isNotEmpty
          ? row.preflightReasonLabel.trim()
          : (existing?.preflightReasonLabel ?? ''),
      preflightReasonDetail: row.preflightReasonDetail.trim().isNotEmpty
          ? row.preflightReasonDetail.trim()
          : (existing?.preflightReasonDetail ?? ''),
      requiresDangerousReview:
          row.requiresDangerousReview ||
          (existing?.requiresDangerousReview ?? false),
      isPurchaseOnly: row.isPurchaseOnly || (existing?.isPurchaseOnly ?? false),
    );
  }

  final builtRows = rowMap.values.toList()
    ..sort((a, b) {
      final nameCompare = a.purchasePartyDisplayName.compareTo(
        b.purchasePartyDisplayName,
      );
      if (nameCompare != 0) return nameCompare;
      return a.sectionCode.compareTo(b.sectionCode);
    });

  return builtRows;
}

String? _normalizeToKnownTdsPartyForIsolate(
  List<String> uniqueTdsParties,
  String? mappedName,
) {
  if (mappedName == null || mappedName.trim().isEmpty) return null;

  final trimmed = mappedName.trim();
  if (uniqueTdsParties.contains(trimmed)) {
    return trimmed;
  }

  final normalized = normalizeName(trimmed);
  for (final party in uniqueTdsParties) {
    if (normalizeName(party) == normalized) {
      return party;
    }
  }

  return null;
}

bool _hasNeedsActionRowsForSectionInIsolate({
  required List<SellerMappingRowVm> rows,
  required Map<String, String> selectedMappings,
}) {
  for (final row in rows) {
    final selectedValue = selectedMappings[row.rowKey];
    final hasPanIssue =
        row.hasMissingOrUncertainPan || row.hasNameOrPanConflict;
    final needsAction =
        row.is26QUnmatched ||
        row.requiresDangerousReview ||
        row.hasReconciliationMismatch ||
        hasPanIssue ||
        ((row.isAboveThreshold || row.hasApplicableTdsImpact) &&
            (selectedValue == null || selectedValue.trim().isEmpty));
    if (needsAction) {
      return true;
    }
  }
  return false;
}

Map<String, dynamic> _serializeSellerMappingForIsolate(SellerMapping mapping) {
  return {
    'id': mapping.id,
    'buyer_name': mapping.buyerName,
    'buyer_pan': mapping.buyerPan,
    'alias_name': mapping.aliasName,
    'section_code': mapping.sectionCode,
    'mapped_pan': mapping.mappedPan,
    'mapped_name': mapping.mappedName,
  };
}

SellerMapping _deserializeSellerMappingForIsolate(Map<String, dynamic> row) {
  return SellerMapping.fromMap(row);
}

Map<String, dynamic> _serializeScreenRowForIsolate(
  SellerMappingScreenRowData row,
) {
  return {
    'purchasePartyDisplayName': row.purchasePartyDisplayName,
    'normalizedAlias': row.normalizedAlias,
    'sectionCode': row.sectionCode,
    'purchasePan': row.purchasePan,
    'purchaseGstNo': row.purchaseGstNo,
    'resolvedSuggestion': row.resolvedSuggestion == null
        ? null
        : {
            'mappedName': row.resolvedSuggestion!.mappedName,
            'mappedPan': row.resolvedSuggestion!.mappedPan,
            'source': row.resolvedSuggestion!.source,
            'helperText': row.resolvedSuggestion!.helperText,
          },
    'isReadOnly': row.isReadOnly,
    'isAboveThreshold': row.isAboveThreshold,
    'hasReconciliationMismatch': row.hasReconciliationMismatch,
    'hasNameOrPanConflict': row.hasNameOrPanConflict,
    'hasApplicableTdsImpact': row.hasApplicableTdsImpact,
    'is26QUnmatched': row.is26QUnmatched,
    'hasMissingOrUncertainPan': row.hasMissingOrUncertainPan,
    'preflightReasonCode': row.preflightReasonCode,
    'preflightReasonLabel': row.preflightReasonLabel,
    'preflightReasonDetail': row.preflightReasonDetail,
    'requiresDangerousReview': row.requiresDangerousReview,
    'isPurchaseOnly': row.isPurchaseOnly,
  };
}

SellerMappingScreenRowData _deserializeScreenRowForIsolate(
  Map<String, dynamic> row,
) {
  final suggestion = row['resolvedSuggestion'] as Map?;
  return SellerMappingScreenRowData(
    purchasePartyDisplayName: row['purchasePartyDisplayName'] as String? ?? '',
    normalizedAlias: row['normalizedAlias'] as String? ?? '',
    sectionCode: row['sectionCode'] as String? ?? '',
    purchasePan: row['purchasePan'] as String? ?? '',
    purchaseGstNo: row['purchaseGstNo'] as String? ?? '',
    resolvedSuggestion: suggestion == null
        ? null
        : SellerMappingResolvedSuggestion(
            mappedName: suggestion['mappedName'] as String? ?? '',
            mappedPan: suggestion['mappedPan'] as String? ?? '',
            source: suggestion['source'] as String? ?? '',
            helperText: suggestion['helperText'] as String? ?? '',
          ),
    isReadOnly: row['isReadOnly'] as bool? ?? false,
    isAboveThreshold: row['isAboveThreshold'] as bool? ?? false,
    hasReconciliationMismatch:
        row['hasReconciliationMismatch'] as bool? ?? false,
    hasNameOrPanConflict: row['hasNameOrPanConflict'] as bool? ?? false,
    hasApplicableTdsImpact: row['hasApplicableTdsImpact'] as bool? ?? false,
    is26QUnmatched: row['is26QUnmatched'] as bool? ?? false,
    hasMissingOrUncertainPan: row['hasMissingOrUncertainPan'] as bool? ?? false,
    preflightReasonCode: row['preflightReasonCode'] as String? ?? '',
    preflightReasonLabel: row['preflightReasonLabel'] as String? ?? '',
    preflightReasonDetail: row['preflightReasonDetail'] as String? ?? '',
    requiresDangerousReview: row['requiresDangerousReview'] as bool? ?? false,
    isPurchaseOnly: row['isPurchaseOnly'] as bool? ?? false,
  );
}

Map<String, dynamic> _serializeRowVmForIsolate(SellerMappingRowVm row) {
  return {
    'purchasePartyDisplayName': row.purchasePartyDisplayName,
    'normalizedAlias': row.normalizedAlias,
    'sectionCode': row.sectionCode,
    'purchasePan': row.purchasePan,
    'purchaseGstNo': row.purchaseGstNo,
    'exactMapping': row.exactMapping == null
        ? null
        : _serializeSellerMappingForIsolate(row.exactMapping!),
    'fallbackMapping': row.fallbackMapping == null
        ? null
        : _serializeSellerMappingForIsolate(row.fallbackMapping!),
    'resolvedSuggestion': row.resolvedSuggestion == null
        ? null
        : {
            'mappedName': row.resolvedSuggestion!.mappedName,
            'mappedPan': row.resolvedSuggestion!.mappedPan,
            'source': row.resolvedSuggestion!.source,
            'helperText': row.resolvedSuggestion!.helperText,
          },
    'isReadOnly': row.isReadOnly,
    'isAboveThreshold': row.isAboveThreshold,
    'hasReconciliationMismatch': row.hasReconciliationMismatch,
    'hasNameOrPanConflict': row.hasNameOrPanConflict,
    'hasApplicableTdsImpact': row.hasApplicableTdsImpact,
    'is26QUnmatched': row.is26QUnmatched,
    'hasMissingOrUncertainPan': row.hasMissingOrUncertainPan,
    'preflightReasonCode': row.preflightReasonCode,
    'preflightReasonLabel': row.preflightReasonLabel,
    'preflightReasonDetail': row.preflightReasonDetail,
    'requiresDangerousReview': row.requiresDangerousReview,
    'isPurchaseOnly': row.isPurchaseOnly,
  };
}

SellerMappingRowVm _deserializeRowVmForIsolate(Map<String, dynamic> row) {
  final exactMapping = row['exactMapping'] as Map?;
  final fallbackMapping = row['fallbackMapping'] as Map?;
  final resolvedSuggestion = row['resolvedSuggestion'] as Map?;

  return SellerMappingRowVm(
    purchasePartyDisplayName: row['purchasePartyDisplayName'] as String? ?? '',
    normalizedAlias: row['normalizedAlias'] as String? ?? '',
    sectionCode: row['sectionCode'] as String? ?? '',
    purchasePan: row['purchasePan'] as String? ?? '',
    purchaseGstNo: row['purchaseGstNo'] as String? ?? '',
    exactMapping: exactMapping == null
        ? null
        : _deserializeSellerMappingForIsolate(
            Map<String, dynamic>.from(exactMapping),
          ),
    fallbackMapping: fallbackMapping == null
        ? null
        : _deserializeSellerMappingForIsolate(
            Map<String, dynamic>.from(fallbackMapping),
          ),
    resolvedSuggestion: resolvedSuggestion == null
        ? null
        : SellerMappingResolvedSuggestion(
            mappedName: resolvedSuggestion['mappedName'] as String? ?? '',
            mappedPan: resolvedSuggestion['mappedPan'] as String? ?? '',
            source: resolvedSuggestion['source'] as String? ?? '',
            helperText: resolvedSuggestion['helperText'] as String? ?? '',
          ),
    isReadOnly: row['isReadOnly'] as bool? ?? false,
    isAboveThreshold: row['isAboveThreshold'] as bool? ?? false,
    hasReconciliationMismatch:
        row['hasReconciliationMismatch'] as bool? ?? false,
    hasNameOrPanConflict: row['hasNameOrPanConflict'] as bool? ?? false,
    hasApplicableTdsImpact: row['hasApplicableTdsImpact'] as bool? ?? false,
    is26QUnmatched: row['is26QUnmatched'] as bool? ?? false,
    hasMissingOrUncertainPan: row['hasMissingOrUncertainPan'] as bool? ?? false,
    preflightReasonCode: row['preflightReasonCode'] as String? ?? '',
    preflightReasonLabel: row['preflightReasonLabel'] as String? ?? '',
    preflightReasonDetail: row['preflightReasonDetail'] as String? ?? '',
    requiresDangerousReview: row['requiresDangerousReview'] as bool? ?? false,
    isPurchaseOnly: row['isPurchaseOnly'] as bool? ?? false,
  );
}
