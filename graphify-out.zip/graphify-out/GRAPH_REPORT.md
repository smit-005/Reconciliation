# Graph Report - E:\reconciliation_app_codex  (2026-04-29)

## Corpus Check
- 172 files · ~110,898 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1398 nodes · 1619 edges · 82 communities detected
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 36 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]
- [[_COMMUNITY_Community 3|Community 3]]
- [[_COMMUNITY_Community 4|Community 4]]
- [[_COMMUNITY_Community 5|Community 5]]
- [[_COMMUNITY_Community 6|Community 6]]
- [[_COMMUNITY_Community 7|Community 7]]
- [[_COMMUNITY_Community 8|Community 8]]
- [[_COMMUNITY_Community 9|Community 9]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]
- [[_COMMUNITY_Community 15|Community 15]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 18|Community 18]]
- [[_COMMUNITY_Community 19|Community 19]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 22|Community 22]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]
- [[_COMMUNITY_Community 36|Community 36]]
- [[_COMMUNITY_Community 37|Community 37]]
- [[_COMMUNITY_Community 38|Community 38]]
- [[_COMMUNITY_Community 39|Community 39]]
- [[_COMMUNITY_Community 40|Community 40]]
- [[_COMMUNITY_Community 41|Community 41]]
- [[_COMMUNITY_Community 42|Community 42]]
- [[_COMMUNITY_Community 43|Community 43]]
- [[_COMMUNITY_Community 44|Community 44]]
- [[_COMMUNITY_Community 45|Community 45]]
- [[_COMMUNITY_Community 46|Community 46]]
- [[_COMMUNITY_Community 47|Community 47]]
- [[_COMMUNITY_Community 48|Community 48]]
- [[_COMMUNITY_Community 49|Community 49]]
- [[_COMMUNITY_Community 50|Community 50]]
- [[_COMMUNITY_Community 51|Community 51]]
- [[_COMMUNITY_Community 52|Community 52]]
- [[_COMMUNITY_Community 53|Community 53]]
- [[_COMMUNITY_Community 54|Community 54]]
- [[_COMMUNITY_Community 55|Community 55]]
- [[_COMMUNITY_Community 56|Community 56]]
- [[_COMMUNITY_Community 57|Community 57]]
- [[_COMMUNITY_Community 58|Community 58]]
- [[_COMMUNITY_Community 59|Community 59]]
- [[_COMMUNITY_Community 60|Community 60]]
- [[_COMMUNITY_Community 61|Community 61]]
- [[_COMMUNITY_Community 62|Community 62]]
- [[_COMMUNITY_Community 63|Community 63]]
- [[_COMMUNITY_Community 64|Community 64]]
- [[_COMMUNITY_Community 65|Community 65]]
- [[_COMMUNITY_Community 66|Community 66]]
- [[_COMMUNITY_Community 67|Community 67]]
- [[_COMMUNITY_Community 68|Community 68]]
- [[_COMMUNITY_Community 69|Community 69]]
- [[_COMMUNITY_Community 70|Community 70]]
- [[_COMMUNITY_Community 71|Community 71]]
- [[_COMMUNITY_Community 72|Community 72]]
- [[_COMMUNITY_Community 73|Community 73]]
- [[_COMMUNITY_Community 74|Community 74]]
- [[_COMMUNITY_Community 75|Community 75]]
- [[_COMMUNITY_Community 76|Community 76]]
- [[_COMMUNITY_Community 77|Community 77]]
- [[_COMMUNITY_Community 78|Community 78]]
- [[_COMMUNITY_Community 79|Community 79]]
- [[_COMMUNITY_Community 80|Community 80]]
- [[_COMMUNITY_Community 81|Community 81]]

## God Nodes (most connected - your core abstractions)
1. `package:flutter/material.dart` - 48 edges
2. `package:reconciliation_app/core/utils/normalize_utils.dart` - 23 edges
3. `package:reconciliation_app/core/theme/app_color_scheme.dart` - 14 edges
4. `package:reconciliation_app/features/reconciliation/models/raw/tds_26q_row.dart` - 14 edges
5. `package:flutter_test/flutter_test.dart` - 14 edges
6. `package:reconciliation_app/core/theme/app_spacing.dart` - 13 edges
7. `package:reconciliation_app/features/reconciliation/models/result/reconciliation_row.dart` - 12 edges
8. `package:reconciliation_app/features/reconciliation/models/result/reconciliation_status.dart` - 12 edges
9. `package:reconciliation_app/features/reconciliation/models/seller_mapping.dart` - 12 edges
10. `package:reconciliation_app/core/theme/app_radius.dart` - 9 edges

## Surprising Connections (you probably didn't know these)
- `RegisterPlugins()` --calls--> `OnCreate()`  [INFERRED]
  E:\reconciliation_app_codex\windows\flutter\generated_plugin_registrant.cc → E:\reconciliation_app_codex\windows\runner\flutter_window.cpp
- `ResizeChannel()` --calls--> `GetInstance()`  [INFERRED]
  E:\reconciliation_app_codex\windows\flutter\ephemeral\cpp_client_wrapper\core_implementations.cc → E:\reconciliation_app_codex\windows\flutter\ephemeral\cpp_client_wrapper\plugin_registrar.cc
- `SetChannelWarnsOnOverflow()` --calls--> `GetInstance()`  [INFERRED]
  E:\reconciliation_app_codex\windows\flutter\ephemeral\cpp_client_wrapper\core_implementations.cc → E:\reconciliation_app_codex\windows\flutter\ephemeral\cpp_client_wrapper\plugin_registrar.cc
- `SetNextFrameCallback()` --calls--> `OnCreate()`  [INFERRED]
  E:\reconciliation_app_codex\windows\flutter\ephemeral\cpp_client_wrapper\flutter_engine.cc → E:\reconciliation_app_codex\windows\runner\flutter_window.cpp
- `ForceRedraw()` --calls--> `OnCreate()`  [INFERRED]
  E:\reconciliation_app_codex\windows\flutter\ephemeral\cpp_client_wrapper\flutter_view_controller.cc → E:\reconciliation_app_codex\windows\runner\flutter_window.cpp

## Communities

### Community 0 - "Community 0"
Cohesion: 0.02
Nodes (98): _acceptSuggestedMapping, AnimatedContainer, _applyAutoMap, AppSearchAutocompleteField, AutoMapDecision, build, _buildBottomBar, _buildEmptyState (+90 more)

### Community 1 - "Community 1"
Cohesion: 0.02
Nodes (74): app_color_scheme.dart, app_radius.dart, app_spacing.dart, app_text_styles.dart, build, MaterialApp, ReconciliationApp, AppRoutes (+66 more)

### Community 2 - "Community 2"
Cohesion: 0.02
Nodes (92): _activeSourceFileCount, _activeSourceRowCount, _allowLoadingFrame, _applicableButNo26QAmount, _applicableButNo26QCount, _applicableButNo26QSellerCount, _applicableButNo26QTds, _applyFilters (+84 more)

### Community 3 - "Community 3"
Cohesion: 0.02
Nodes (86): AppSectionCard, AppStatusBadge, build, _BuyerDetailPill, BuyerManagementScreen, _BuyerOverviewCard, Column, Container (+78 more)

### Community 4 - "Community 4"
Cohesion: 0.02
Nodes (87): addScore, _appendGenericLedgerNarration, _buildMappedHeaders, _buildPreviewData, _buildPreviewDataWithProfile, buildSampleSignature, _classifyGenericLedgerRow, _columnScoreCacheKey (+79 more)

### Community 5 - "Community 5"
Cohesion: 0.03
Nodes (75): NormalizedLedgerRow, copyWith, NormalizedTransactionRow, PurchaseRow, _extractSectionFromText, _inferSection, _isKnownSection, Tds26QRow (+67 more)

### Community 6 - "Community 6"
Cohesion: 0.03
Nodes (59): app/app.dart, ../../core/utils/normalize_utils.dart, buyers, _createImportFormatProfilesTable, _createSellerMappingsTable, DBHelper, import_format_profiles, _migrateBuyersTable (+51 more)

### Community 7 - "Community 7"
Cohesion: 0.03
Nodes (68): dart:async, AlertDialog, _applySellerMappingChanges, BoxDecoration, build, _buildBatchMappingReviewCard, _buildBottomActionBar, _buildHeader (+60 more)

### Community 8 - "Community 8"
Cohesion: 0.05
Nodes (38): FlutterEngine(), RelinquishEngine(), ReloadSystemFonts(), SetNextFrameCallback(), ShutDown(), FlutterViewController(), ForceRedraw(), HandleTopLevelWindowProc() (+30 more)

### Community 9 - "Community 9"
Cohesion: 0.04
Nodes (51): add, addAll, addToIndex, _analyzeWithExistingMappings, buildResult, copyWith, _deserializeNormalizedRowForIsolate, _deserializePreflightResultForIsolate (+43 more)

### Community 10 - "Community 10"
Cohesion: 0.04
Nodes (47): buildSellerDisplayKey, buildSellerSectionDisplayKey, sortSections, copyWith, ReconciliationRow, build, _buildComputedDifference, _buildExplanation (+39 more)

### Community 11 - "Community 11"
Cohesion: 0.04
Nodes (51): dart:io, dart:typed_data, _applyNumberFormat, _autoFitPivot, _autoFitUsefulColumns, _buildExportFileName, ExcelExportService, _getDownloadsPath (+43 more)

### Community 12 - "Community 12"
Cohesion: 0.04
Nodes (49): AppCompactSelectField, build, _displayLabel, Function, Icon, LayoutBuilder, SizedBox, Align (+41 more)

### Community 13 - "Community 13"
Cohesion: 0.04
Nodes (45): BatchMappingReviewItem, copyWith, LedgerUploadFile, BatchMappingReviewItem, BatchMappingReviewService, _buildItem, _isRequiredFieldMapped, compute (+37 more)

### Community 14 - "Community 14"
Cohesion: 0.04
Nodes (46): build, Container, ReconciliationAnalyticsPanel, SizedBox, Text, build, _buildApplicableNo26QSummary, _buildFooterNote (+38 more)

### Community 15 - "Community 15"
Cohesion: 0.06
Nodes (30): flutter(), ResizeChannel(), Send(), SendResponseData(), SetChannelWarnsOnOverflow(), SetMessageHandler(), flutter(), flutter() (+22 more)

### Community 16 - "Community 16"
Cohesion: 0.05
Nodes (41): dart:math, _autoMapBestGuess, BoxDecoration, build, _buildFieldCard, _buildFieldsPanel, _buildFileInfoCard, _buildInfoChip (+33 more)

### Community 17 - "Community 17"
Cohesion: 0.06
Nodes (33): AlertDialog, Align, _amountText, build, Color, Container, _DataRowCard, _DataRowCardState (+25 more)

### Community 18 - "Community 18"
Cohesion: 0.06
Nodes (27): SectionRuleRegistry, _apply194I, _apply194J, _applyConfiguredRule, applyRule, _clean, _compareThreshold, _matchesThresholds (+19 more)

### Community 19 - "Community 19"
Cohesion: 0.08
Nodes (22): buyer_repository.dart, BuyerRepository, BuyerStore, build, BuyerManagementScreen, _BuyerManagementScreenState, Card, clearForm (+14 more)

### Community 20 - "Community 20"
Cohesion: 0.11
Nodes (17): build, _chip, Container, FileInfoCard, SizedBox, build, Container, DataCell (+9 more)

### Community 21 - "Community 21"
Cohesion: 0.25
Nodes (7): extractPanFromGstin, isLegacyUnsupportedSection, looksLikePan, normalizeName, normalizePan, normalizeSection, sectionDisplayLabel

### Community 22 - "Community 22"
Cohesion: 0.33
Nodes (5): compareFinancialYearMonthKeys, compareMonthKeys, DateTime, financialYearFromMonthKey, normalizeMonth

### Community 23 - "Community 23"
Cohesion: 0.33
Nodes (5): ImportMappingService, isAmountField, isDateField, _normalizeCanonicalKey, ../models/mapping_field_option.dart

### Community 24 - "Community 24"
Cohesion: 0.5
Nodes (3): SectionRateConfig, SectionRuleConfig, SectionThresholdRule

### Community 25 - "Community 25"
Cohesion: 0.5
Nodes (3): SkippedRowSample, SkippedRowSummary, SkippedSellerImpact

### Community 26 - "Community 26"
Cohesion: 0.5
Nodes (3): _debugDuplicateSourceSectionLeakage, _debugSectionCounts, _debugSummaryMap

### Community 27 - "Community 27"
Cohesion: 0.67
Nodes (2): parseDouble, round2

### Community 28 - "Community 28"
Cohesion: 0.67
Nodes (2): copyWith, ReconciliationDebugInfo

### Community 29 - "Community 29"
Cohesion: 0.67
Nodes (2): ReconciliationRowExplanation, ReconciliationRowExplanationValue

### Community 30 - "Community 30"
Cohesion: 1.0
Nodes (1): MainActivity

### Community 31 - "Community 31"
Cohesion: 1.0
Nodes (1): AppRadius

### Community 32 - "Community 32"
Cohesion: 1.0
Nodes (1): AppSpacing

### Community 33 - "Community 33"
Cohesion: 1.0
Nodes (1): Buyer

### Community 34 - "Community 34"
Cohesion: 1.0
Nodes (1): TransactionModel

### Community 35 - "Community 35"
Cohesion: 1.0
Nodes (1): ReconciliationStatus

### Community 36 - "Community 36"
Cohesion: 1.0
Nodes (1): ReconciliationSummary

### Community 37 - "Community 37"
Cohesion: 1.0
Nodes (1): ResolvedSellerIdentity

### Community 38 - "Community 38"
Cohesion: 1.0
Nodes (1): ColumnMappingResult

### Community 39 - "Community 39"
Cohesion: 1.0
Nodes (1): ExcelPreviewData

### Community 40 - "Community 40"
Cohesion: 1.0
Nodes (1): ImportAuditRecord

### Community 41 - "Community 41"
Cohesion: 1.0
Nodes (1): ImportFormatProfile

### Community 42 - "Community 42"
Cohesion: 1.0
Nodes (1): MappingFieldOption

### Community 43 - "Community 43"
Cohesion: 1.0
Nodes (1): ExcelPreviewData

### Community 44 - "Community 44"
Cohesion: 1.0
Nodes (0): 

### Community 45 - "Community 45"
Cohesion: 1.0
Nodes (0): 

### Community 46 - "Community 46"
Cohesion: 1.0
Nodes (0): 

### Community 47 - "Community 47"
Cohesion: 1.0
Nodes (0): 

### Community 48 - "Community 48"
Cohesion: 1.0
Nodes (0): 

### Community 49 - "Community 49"
Cohesion: 1.0
Nodes (0): 

### Community 50 - "Community 50"
Cohesion: 1.0
Nodes (0): 

### Community 51 - "Community 51"
Cohesion: 1.0
Nodes (0): 

### Community 52 - "Community 52"
Cohesion: 1.0
Nodes (0): 

### Community 53 - "Community 53"
Cohesion: 1.0
Nodes (0): 

### Community 54 - "Community 54"
Cohesion: 1.0
Nodes (0): 

### Community 55 - "Community 55"
Cohesion: 1.0
Nodes (0): 

### Community 56 - "Community 56"
Cohesion: 1.0
Nodes (0): 

### Community 57 - "Community 57"
Cohesion: 1.0
Nodes (0): 

### Community 58 - "Community 58"
Cohesion: 1.0
Nodes (0): 

### Community 59 - "Community 59"
Cohesion: 1.0
Nodes (0): 

### Community 60 - "Community 60"
Cohesion: 1.0
Nodes (0): 

### Community 61 - "Community 61"
Cohesion: 1.0
Nodes (0): 

### Community 62 - "Community 62"
Cohesion: 1.0
Nodes (0): 

### Community 63 - "Community 63"
Cohesion: 1.0
Nodes (0): 

### Community 64 - "Community 64"
Cohesion: 1.0
Nodes (0): 

### Community 65 - "Community 65"
Cohesion: 1.0
Nodes (0): 

### Community 66 - "Community 66"
Cohesion: 1.0
Nodes (0): 

### Community 67 - "Community 67"
Cohesion: 1.0
Nodes (0): 

### Community 68 - "Community 68"
Cohesion: 1.0
Nodes (0): 

### Community 69 - "Community 69"
Cohesion: 1.0
Nodes (0): 

### Community 70 - "Community 70"
Cohesion: 1.0
Nodes (0): 

### Community 71 - "Community 71"
Cohesion: 1.0
Nodes (0): 

### Community 72 - "Community 72"
Cohesion: 1.0
Nodes (0): 

### Community 73 - "Community 73"
Cohesion: 1.0
Nodes (0): 

### Community 74 - "Community 74"
Cohesion: 1.0
Nodes (0): 

### Community 75 - "Community 75"
Cohesion: 1.0
Nodes (0): 

### Community 76 - "Community 76"
Cohesion: 1.0
Nodes (0): 

### Community 77 - "Community 77"
Cohesion: 1.0
Nodes (0): 

### Community 78 - "Community 78"
Cohesion: 1.0
Nodes (0): 

### Community 79 - "Community 79"
Cohesion: 1.0
Nodes (0): 

### Community 80 - "Community 80"
Cohesion: 1.0
Nodes (0): 

### Community 81 - "Community 81"
Cohesion: 1.0
Nodes (0): 

## Knowledge Gaps
- **1044 isolated node(s):** `MainActivity`, `main`, `app/app.dart`, `ReconciliationApp`, `build` (+1039 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **Thin community `Community 30`** (2 nodes): `MainActivity.kt`, `MainActivity`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 31`** (2 nodes): `app_radius.dart`, `AppRadius`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 32`** (2 nodes): `app_spacing.dart`, `AppSpacing`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 33`** (2 nodes): `buyer.dart`, `Buyer`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 34`** (2 nodes): `transaction.dart`, `TransactionModel`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 35`** (2 nodes): `reconciliation_status.dart`, `ReconciliationStatus`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 36`** (2 nodes): `reconciliation_summary.dart`, `ReconciliationSummary`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 37`** (2 nodes): `resolved_seller_identity.dart`, `ResolvedSellerIdentity`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 38`** (2 nodes): `column_mapping_result.dart`, `ColumnMappingResult`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 39`** (2 nodes): `excel_preview_data.dart`, `ExcelPreviewData`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 40`** (2 nodes): `import_audit_record.dart`, `ImportAuditRecord`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 41`** (2 nodes): `import_format_profile.dart`, `ImportFormatProfile`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 42`** (2 nodes): `mapping_field_option.dart`, `MappingFieldOption`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 43`** (2 nodes): `excel_preview_builder.dart`, `ExcelPreviewData`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 44`** (2 nodes): `flutter()`, `binary_messenger_impl.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 45`** (2 nodes): `flutter()`, `byte_buffer_streams.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 46`** (2 nodes): `texture_registrar_impl.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 47`** (2 nodes): `flutter()`, `binary_messenger.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 48`** (2 nodes): `flutter()`, `byte_streams.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 49`** (2 nodes): `GpuPreference()`, `dart_project.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 50`** (2 nodes): `encodable_value.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 51`** (2 nodes): `event_sink.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 52`** (2 nodes): `event_stream_handler.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 53`** (2 nodes): `event_stream_handler_functions.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 54`** (2 nodes): `flutter_engine.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 55`** (2 nodes): `flutter_view.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 56`** (2 nodes): `flutter_view_controller.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 57`** (2 nodes): `method_call.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 58`** (2 nodes): `method_result.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 59`** (2 nodes): `method_result_functions.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 60`** (2 nodes): `plugin_registrar.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 61`** (2 nodes): `plugin_registrar_windows.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 62`** (2 nodes): `plugin_registry.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 63`** (2 nodes): `standard_codec_serializer.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 64`** (2 nodes): `standard_message_codec.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 65`** (2 nodes): `standard_method_codec.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 66`** (2 nodes): `texture_registrar.h`, `flutter()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 67`** (1 nodes): `build.gradle.kts`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 68`** (1 nodes): `settings.gradle.kts`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 69`** (1 nodes): `build.gradle.kts`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 70`** (1 nodes): `reconciliation_view_mode.dart`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 71`** (1 nodes): `upload_mapping_status.dart`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 72`** (1 nodes): `generated_plugin_registrant.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 73`** (1 nodes): `flutter_export.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 74`** (1 nodes): `flutter_messenger.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 75`** (1 nodes): `flutter_plugin_registrar.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 76`** (1 nodes): `flutter_texture_registrar.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 77`** (1 nodes): `flutter_windows.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 78`** (1 nodes): `engine_method_result.cc`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 79`** (1 nodes): `resource.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 80`** (1 nodes): `utils.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 81`** (1 nodes): `win32_window.h`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `package:flutter/material.dart` connect `Community 1` to `Community 0`, `Community 2`, `Community 3`, `Community 6`, `Community 7`, `Community 12`, `Community 13`, `Community 14`, `Community 16`, `Community 17`, `Community 19`, `Community 20`?**
  _High betweenness centrality (0.248) - this node is a cross-community bridge._
- **Why does `package:reconciliation_app/core/utils/normalize_utils.dart` connect `Community 5` to `Community 0`, `Community 2`, `Community 3`, `Community 4`, `Community 6`, `Community 7`, `Community 9`, `Community 10`, `Community 14`, `Community 17`, `Community 18`?**
  _High betweenness centrality (0.143) - this node is a cross-community bridge._
- **Why does `package:flutter/foundation.dart` connect `Community 9` to `Community 0`, `Community 13`, `Community 4`, `Community 5`?**
  _High betweenness centrality (0.057) - this node is a cross-community bridge._
- **What connects `MainActivity`, `main`, `app/app.dart` to the rest of the system?**
  _1044 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Community 0` be split into smaller, more focused modules?**
  _Cohesion score 0.02 - nodes in this community are weakly interconnected._
- **Should `Community 1` be split into smaller, more focused modules?**
  _Cohesion score 0.02 - nodes in this community are weakly interconnected._
- **Should `Community 2` be split into smaller, more focused modules?**
  _Cohesion score 0.02 - nodes in this community are weakly interconnected._